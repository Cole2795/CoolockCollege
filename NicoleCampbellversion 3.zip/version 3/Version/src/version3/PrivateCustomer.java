/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package version3;

/**
 *
 * @author Nicole
 */
public class PrivateCustomer extends Customer {
    
    private int points;
    
    public PrivateCustomer(){
        this.points = 40;
    }

    public int getPoints() {
        return points;
    }
    
    public PrivateCustomer(String name, String address, String email, String type, int id, int points){
        super(name, address, email,type, id);
        this.points = points;
    }
    
    public void setPoints(int points){
        this.points = points;
    }
    
    public int CalculateLoyaltyPoint(int orderValue){
        return points + orderValue * 100;
    }
    
    public void increaseQuantity(int increase){
        //boolean success = false;
        // if(increase > 0){
             //item_quanity += increase;
            this.points += increase;
           // return true;
             
         //}
         // return increase;
    }
    
    public String toString(){
        return super.toString() + "\nPoint : " + points;
    }
    
}
