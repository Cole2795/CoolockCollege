/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package version3;

import java.util.Objects;

/**
 *
 * @author Nicole
 */
public class Customer {
    
    private String name, address, email, type;
    private int id;
    private static int  nextCustomerId = 99; 
    
    public Customer(){
        id = nextCustomerId;
        name = "Nicole";
        address = "Balbriggan";
        email = "D00187051@Student.dkit.ie";
        type = "anything";
        nextCustomerId++;
        
    }
    
    public Customer(String name, String address, String email, String type,  int id){
        this.id = nextCustomerId;
        this.name = name;
        this.address = address;
        this.email = email;
        this.type = type;
        nextCustomerId++;
    }
    
    public void setName(String name){
        this.name = name;
    }
    
    public String getName(){
        return name;
    }
    
    public void setAddress(String address){
        this.address = address;
    }
    
    public String getAddress(){
        return address;
    }
    
    public void setEmail(String email){
        this.email = email;
    }
    
    public String getEmail(){
        return email;
    }
    
    public void setId(int id){
        this.id = id;
    }
    
    public int getId(){
        return id;
    }
    
    public int getNextCustomerID(){
        return nextCustomerId;
    }

//    @Override
//    public int hashCode() {
//        int hash = 5;
//        return hash;
//    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Customer other = (Customer) obj;
        if (this.id != other.id) {
            return false;
        }
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        if (!Objects.equals(this.address, other.address)) {
            return false;
        }
        return true;
    }
    
    public void setType(String type){
        this.type = type;
    }
    
    public String getType(){
        return type;
    }
    
    
   @Override 
    public String toString(){
        return "\nCustomer Details\nID " + id + "\nName : " + name + "\nAddress : " + address + "\nEmail : " + email;
    }
    
}
