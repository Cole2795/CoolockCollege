//Item class
package version3;

import java.util.Objects;

public class Item {
        //variable or fields
	private String name;
	private int item_id;
	private int item_quanity;
	private double unit_price;
        private static int  nextItemId = 99;   
    // first constructor 
    //second constructor
    public Item(){
        this.item_id = nextItemId;
        this.name = "Unknown";
        this.item_quanity = 0;
        this.unit_price = 0;
        nextItemId++;
        
    }
//parametrised constructor    
    public Item(String n, int itemid, int itemqty, double up) {
    	this.name = n;
    	this.item_id = itemid;
    	this.item_quanity = itemqty;
    	this.unit_price = up;
        nextItemId++;
    }//end constructor
    

    //set item name
    public boolean setName(String itemName) {
        if (itemName.length()>=3) {
        this.name = itemName;
        return true;
    }else{
            return false;
        }
    }
    
    //get item name
    public String getName(){
    	return name;
    }//end getName
   
    //set id
    public void setItem_ID(int itemid){
    	this.item_id = itemid;
    }//end set item id
    //get id
    public int getItem_ID(){
    	return item_id;
    }//end get ItemID
    
    //set quantity
//    public void setItem_Quanity(int itemqty){
//    	this.item_quanity = itemqty;
//    }//end Set item qty
    /**********************OR**********************************/
    public boolean setItem_Quanity(int quantity){
        if(quantity>0){
            this.item_quanity = quantity;
            return true;
        }
        
            return false;
        
    }
    //get quantity
    public int getItem_Quanity(){
    	return item_quanity;
    }//end get item Quanity
    
    // get unit price
    public double getUnit_Price() {
        return unit_price;
    }

    // set unit price
    public boolean setUnitPrice(double itemUnitPrice) {
        if(itemUnitPrice>0){
        this.unit_price = itemUnitPrice;
        return true;
    }else{
            return false;
        }
    }
    //stock
    public boolean inStock(int st){
      if(item_quanity > st){
          return true;
      }
      else{
          return false;
      }
   }//inStock
    

   
   //need Increase Quantity
    public int increaseQuantity(int increase){
        //boolean success = false;
        // if(increase > 0){
             //item_quanity += increase;
            this.item_quanity += increase;
           // return true;
             
         //}
          return item_quanity;
    }
    //decrease quantity
    public int decreaseQuantity(int decrease){
       // boolean success = false;
        // if(item_quanity >  0){
             this.item_quanity -= decrease;
             //return true;
             
        //// }
        // else if (item_quanity < 0){
          //   System.out.println("Not Available");
         //}
         return item_quanity;
    }

//    @Override
//    public int hashCode() {
//        int hash = 3;
//        return hash;
//    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Item other = (Item) obj;
        if (!Objects.equals(this.name, other.name)) {
            return false;
        }
        return true;
    }
    
    
    
    
    //toString print out details in app class or use to display information
    public String toString(){
    	return "\nName: " + name + " \nItem ID: "+ item_id + " \nItem Quanity : " + item_quanity + " \nUnit Price : " + unit_price;
    }//end toString


}//end class
