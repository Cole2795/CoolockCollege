
package version3;

import java.io.*;
import java.util.ArrayList;
import java.io.File;
import java.util.*;
import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
import java.io.FileOutputStream;
public class startupApp {
    
    public static void main(String args []) throws FileNotFoundException, IOException{
       
        
        try {
            //ArrayList
            CustomerData cd = new CustomerData();
             Stock it = new Stock();
            
            BufferedReader in = new BufferedReader(new FileReader("Customer.txt"));
            String line = in.readLine();
           

            while (line != null) {
                    StringTokenizer sText = new StringTokenizer(line);
                    String type, name, address, email;
                    while (sText.hasMoreTokens()) {
                        name = sText.nextToken();
                        address = sText.nextToken();
                        email = sText.nextToken();
                        type = sText.nextToken();
                        int id = Integer.parseInt(sText.nextToken());
                        //if (type.equalsIgnoreCase("B")) {
                        double balance = Double.parseDouble(sText.nextToken());
                        double credit = Double.parseDouble(sText.nextToken());
                        BusinessCustomer bc1 = new BusinessCustomer(name, address, email, type, id, balance, credit);
                        cd.addCustomer(bc1);
                       
        // } else {
        //int points = Integer.parseInt(sText.nextToken());
        //cd.addCustomer(new PrivateCustomer(name, address, email, type, points));
        }
        line = in.readLine();
     }
     cd.showallcustomer();
     in.close();


        File i = new File("Item.txt");
        Scanner kbReader = new Scanner(i);
        while(kbReader.hasNext()){
            String name = kbReader.next();
            int item_id = kbReader.nextInt();
            int item_quanity = kbReader.nextInt();
            int unit_price = kbReader.nextInt();
            Item i1 = new Item(name, item_id, item_quanity, unit_price);

            //add item
            it.addstock(i1);
            
        }//end while
        
        it.showallStock();
        kbReader.close();
        
        }catch (IOException ex) {
               System.out.println(ex.toString());
        }
        
        BusinessCustomer b1 = new BusinessCustomer("ashley", "Balbriggan", "ashley32@hotmail.com", "book", 58, 10, 88);
         
        try{
            FileOutputStream out = new FileOutputStream("Clients.bin");
            ObjectOutputStream ccs = new ObjectOutputStream(out);
            
            ccs.writeObject(b1);
            ccs.flush();
            
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("products.bin"));
            System.out.println("" + (String) ois.readObject());
            
            byte[] read = (byte[]) ois.readObject();
            String s2 = new String(read);
            System.out.println("" + s2);
                    
                    
         }catch (Exception ex){
             ex.printStackTrace();
         }
//        
//        try {
//            FileInputStream inFile_Customer = new FileInputStream("Clients.bin");
//            ObjectInputStream ois_Customer = new ObjectInputStream(inFile_Customer);
//            ArrayList<Customer> CustomerData = (ArrayList<Customer>)ois_Customer.readObject();
//
//        
//
//            FileInputStream inFile_Item = new FileInputStream("products.bin");
//            ObjectInputStream ois_Item = new ObjectInputStream(inFile_Item);
//            ArrayList<Item> Stock = (ArrayList<Item>)ois_Item.readObject();
//
//        
//
//            } catch (ClassNotFoundException |IOException | ClassCastException e) {
//                e.printStackTrace();
//            } ObjectInputStream ccs = new ObjectInputStream(new FileInputStream("clients.bin"));
//        ccs.writeobject();
//        ccs.close();
//        
//        System.out.println("Reading Array");
//        ObjectInputStream iit = new ObjectInputStream(new FileInputStream("products.bin"));
//        Item [] arrayFromFile = (Item [])iit.readObject();
//        iit.close();
//        for(Item t.arrayFromFile){
//            System.out.println("");
//        }

//        FileInputStream prodis = new FileInputStream("products.bin");
//        ObjectInputStream pois = new ObjectInputStream(prodis);
//        myStock = ((Stock)pois.readObject());
//        pois.close();
//        
//        FileInputStream clientis = new FileInputStream("products.bin");
//        ObjectInputStream clis = new ObjectInputStream(clientis);
//        myCustomer = ((CustomerData)pois.readObject());
//        clis.close();
        
       
    }//end main method
    
    
    
    
}//end class
