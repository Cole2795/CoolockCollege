//Order class 
package nicoleproject;

/**
 *
 * @author D00187051
 */
public class Order {
        //variable or fields
    private int orderQuantity;
    private Item it;
    private int orderId;
    private static int nextOrderId = 99;
    private double cost;
    //first constructor
    // Default Constructor    
    public Order() {
        this.orderQuantity = 0; 
        this.it=null;
        nextOrderId++;
        orderId = nextOrderId;
        calCost();  
    }

// Parametrised Constructor
    public Order( int orderQuantity, Item it) {
        this.it = it;
        this.orderQuantity = orderQuantity;
        nextOrderId++;
        orderId = nextOrderId;
        calCost();
    }

// get item
    public Item getItem() {
        return it;
    }

    
// get order id
    public int getOrderId() {
        return orderId;
    }    
    
// set order id
    public void setOrderId(int orderId) {
        this.orderId = orderId;
    }
    
// set item id
    public void setItemId(int orderId) {
        this.orderId = orderId;
    }

    
// get order quantity
    public int getOrderQuantity() {
        return orderQuantity;
    }

// set order quantity
    public boolean setOrderQuantity(int q) {
        if(q>0) {
            orderQuantity = q;
            return true;
        }
        return false;
    }
 
// set cost    
    public boolean setCost(double c) {
        if (c>0) {
          cost = c;
          return true;
        }
        return false;
    }
    
// checks the quantity of order is in stock and change quantity in stock
    public boolean makeOrder(Item it, int change) {
        if (it.getItem_Quanity()>orderQuantity) {
            change = orderQuantity;
            it.setItem_Quanity(change);
            calCost();
            return true;
            
        }else{
            it.setName("Invalid");
            return false;
        }
    }
 // Calculate cost and discouts
    private boolean calCost() {
        cost = it.getUnit_Price() * orderQuantity;       //cost =  unit price * quantity of items in order
        double discount;
        if (cost > 5000) {//if order > €5000, there is a 4% discount
            discount = cost * 0.04;
            cost -= discount;
            return true;
        } else if (cost <= 5000 && cost >= 1000) {//if order >= 1000 and <= 5000 , there is a 3% discount
            discount = cost * 0.03;
            cost -= discount;
            return true;
        } else if(cost<1000 && cost>0){//if order > 0 and <=  1000 it's normal price
            discount = 0;
            cost -= discount;
            return true;
        } else {//if order <= 0  
            return false;
        }
        
    }
    
    // get the gost
     public double getCost(){
        return cost;//returns cost
    }
    
    //toSTring print out details in app class or display information
    public String toString(){
    	return "\nOrder ID: " + orderId + "\nOrder Quanity : " + orderQuantity + "\nCost : " + cost + "\n" +  it.toString();
    }//end toString


}//end class
