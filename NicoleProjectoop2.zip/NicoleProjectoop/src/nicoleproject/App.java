 /*Nicole Campbell Project
App class
*/

package nicoleproject;

import java.io.*;
import java.util.*;
import java.util.Date;
public class App {
    
    public static void main (String args[]){
        Scanner kbReader = new Scanner(System.in);
        Date d = new Date();
        System.out.println(d);
        
        //create object Item and Order
        System.out.println("");
        System.out.println("WELCOME TO BOOK STORE");
        
    	Item i1 = new Item("Harry Potter", 4, 5, 56);
        Item i12 = new Item("Peter Pan", 8, 2, 8);
        Item i13 = new Item("BFG", 4, 9, 20);
        Item i14 = new Item("The Maze Runner", 32, 5, 22);
        Item i15 = new Item("Me before you", 11, 9, 25);
        
        //array item and order should be stored in arrays
        Item pack [] = {i1, i12, i13, i14, i15};
        AllStock(pack);
        
        //Array of order items
        Order or1 = new Order(1, i1);
        Order or2 = new Order(2, i12);
        Order or3 = new Order(3, i13);
        Order or4 = new Order(4, i14);
        Order or5 = new Order(5, i15);
        
        //array item and order should be stored in arrays
      
        Order packs [] = {or1, or2, or3, or4, or5};
        NewOrder(packs);
        
        System.out.println("");
        
        
        //update Quantity of item  in stock is accept ordered
         System.out.println("What book are you looking for? :");
        String book = kbReader.nextLine();
        int found = 0;
        //use for loop to find name of book
        for(int i =0; i<pack.length; i++){
            //when you use pack[i].getName().equals(book) which mean name of book has already up in item object 
            if(pack[i].getName().equals(book)){
                if(found == 0){
                    found = 1;
                    System.out.println("\nName : " + pack[i].getName() + "\nItem Quanity : " + pack[i].getItem_Quanity() + "\nPrice : " + pack[i].getUnit_Price());
                   
                    System.out.println("How many book you want?");
                    int number = kbReader.nextInt();
                    
                    System.out.println("\nName : " + pack[i].getName() + "\nItem Quantity have " + pack[i].decreaseQuantity(number) +  " Left.");
                    System.out.println("Name: " + pack[i].getName() + "\nPrice " + pack[i].getUnit_Price() * number);
                       
                }
            }
        }   
        
        //add Stock shipment
        System.out.println("Add Stock ");
        System.out.println("\nName : " + i13.getName() + "\nAdd Stock " + i13.increaseQuantity(4));
        
        
        // printing out the name, item code/id, quantity and unit price of first item          
        System.out.println("The name of the item is: " + i1.getName());
        System.out.println("The quantity of the item in stock is: " + i1.getItem_Quanity());
        System.out.println("The unit price of this item is: " + i1.getUnit_Price());

        System.out.println("\n");
// Printing out order id, order item and order quantity of first order
        System.out.println("The order id is: " + or1.getOrderId());
        System.out.println("The order quantity is: " + or1.getOrderQuantity());

// Display order given id        

        Order ord = new Order();
        ord.getOrderId();

         for (int i=0; i<packs.length; i++) {
            if (ord.getOrderId()== 100) {
                System.out.println(pack[i]);
            } else {
                System.out.println("Invalid");
            }
           }
       
           
        
        
                
    }//end main method
    
    // Displaying stock array
    public static void AllStock(Item[] pack) {
        for (int i = 0; i < pack.length; i++) {
            System.out.println(pack[i]);
        }
        System.out.println("\n");
    }

// Displaying order array      
    public static void NewOrder(Order[] newOrder) {
        for (int i = 0; i < newOrder.length; i++) {
            System.out.println(newOrder[i]);
        }
        System.out.println("\n");
    }
    
    
        
        
    
     
    
}//end class
    

