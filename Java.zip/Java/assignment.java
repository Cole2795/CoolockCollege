
/**
 * @(#)assignment.java
 *
 *
 * @author
 * @version 1.00 2016/4/8
 */
import java.io.*;
import java.util.*;
public class assignment {

    public static void main(String args[]) {

    	Scanner kbReader = new Scanner(System.in);
    	String name, address, course_name;
    	int id, course_number, dob;
    	int found = 0, position = 0;

		System.out.println("Enter number of students: ");
    	int numstudents = kbReader.nextInt();

    	student arraystudent[] = new student[numstudents];

    	for(int i =0; i<arraystudent.length; i++){
    		System.out.println("\nStudent " + (i+1));
    		System.out.println();
    		System.out.println("Enter student name: ");
    		name = kbReader.next();

    		System.out.println("Enter id for " + name + ":");
    		id = kbReader.nextInt();

    		System.out.println("Enter address for " + name + ":");
    		address = kbReader.next();

    		System.out.println("Enter computer name: ");
    		course_name = kbReader.next();

    		System.out.println("Enter course id: ");
    		course_number = kbReader.nextInt();

    		System.out.println("Is the applicant a mature student (y/n)");
//m_app = kbReader.next();
  //  		m_app = Ucase(arraystudent);
    		/*while(!m_app.matches("Y") || (m_appmatches("N"))){
    			if(y)
    		}//end while*/

    		//create student
    		//students s = new students(name, id, address, a1);
    		//create matureStudent
    		//maturestudent m = new maturestudent(name, id, address, a1, dob);


    	}//end for

    	System.out.println("Enter choice: ");
    	int choice = kbReader.nextInt();
    	System.out.println("1. View Course/Personal Details");
    	System.out.println("2. Edit Course/Personal Details");
    	System.out.println("3. Quit");

    	while(choice !=3){
    		if(choice == 1){

    			//System.out.println("Student Details " + name[position] + id[position] + address[position] + course_name[postion] + course_number[position]);
    		}//end if

    	}

    }//end main method


}//end class