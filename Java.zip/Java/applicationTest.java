/**
 * @(#)applicationTest.java
 *
 *
 * @author
 * @version 1.00 2016/4/7
 */
import java.io.*;
import java.util.*;
//import java.until.Date.;

public class applicationTest {

     public static void main (String args[]) {

	Scanner kbReader = new Scanner(System.in);
//	String name, address, course_name;
//	int id, course_number, dob;

	//applicant ap[] = new applicant[4];

	/*application a1 = new application("computing", 1);
	ap[0] = new applicant("Keith", 23423);
	ap[1] = new student("nicole", 234, "Dublin", "art", 34);
	ap[2] = new maturestudent("Ashley", 343, "Meath", "Business", 34, 12/03/1993);
	*/
	student s[] = new student[1];
    for (int i = 0; i<s.length;i++){
    	System.out.println();
    	System.out.println("Enter name : ");
    	String name = kbReader.next();
    	System.out.println("Enter id for " + name + ":");
    	int id = kbReader.nextInt();
    	System.out.println("Enter address for " + name + ":");
    	String address = kbReader.next();
    	System.out.println("Enter course name: ");
    	String course_name = kbReader.next();
    	System.out.println("Enter course id: ");
    	int course_number = kbReader.nextInt();

    	application a1 = new application(course_name, course_number);

    }//end for

	for(int i = 0;i<s.length;i++){
		System.out.println();
		//System.out.println("Number of students is " + s[i].getcounter());
		System.out.println(s[i].toString());
	}//end for

    }//end main method


}//end class