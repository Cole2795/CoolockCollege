/**
 * @(#)ValidateAge.java
 *take an age from the user and pass it to a method to
 *validate it i.e. check it only contains digits
 *The method should keep asking the user for a valid age if the user is entering non digits
 *The method should return an age, digits only
 *
 *Tell the user if they are old enough to vote
 *
 * @author
 * @version 1.00 2015/10/22
 */
import java.io.*;
import java.util.*;
public class ValidateAge {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	String strage;
    	int age;

    	System.out.println("Please enter your age : ");
    	//take input
    	strage = kbReader.next();

		//pass the input to a method to validate teh input, i.e. check it only contains digits
    	age = agecheck(strage);

    	if(age>17){
       		System.out.println("You can vote");
    	}
    	else{
    		System.out.println("You can not vote");
    	}
    }//end main method

	//this method will check that mstrage only contains digits
	//if it does not only contain digits it will ask the user for an input again
	//eventually when an input only containing digits is entered it will change the input to an int and return this int value
    public static int agecheck(String mstrage){
    	Scanner kbReader2 = new Scanner(System.in);
    	while(!mstrage.matches("\\d{4}")){
    		System.out.println("Error, number only");
    		System.out.println("Please enter your age : ");
    		mstrage = kbReader2.next();

    	}//end while
    	return Integer.parseInt(mstrage);	//change mstrage to an int and return it to the method call
    }//end agecheck


}