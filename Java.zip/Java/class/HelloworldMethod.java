/**
 * @(#)HelloworldMethod.java
 *
 *
 * @author
 * @version 1.00 2015/10/1
 */


public class HelloworldMethod {

    public static void main (String args[]) {

    //call HelloWorld method
    HelloWorld(); //method name with empty brackets

    }//end main method

    public static void HelloWorld () {
    	System.out.println("Hello World");
    }//end main method HelloWorld

}//end class