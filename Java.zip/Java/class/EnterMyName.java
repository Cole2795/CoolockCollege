/**
 * @(#)EnterMyName.java
 *Nicole Campbell
 *prompt the user to enter their name and print "Hello __"
 *
 * @author
 * @version 1.00 2015/9/16
 */
import java.util.Date; 	   //allows us to use dates
import java.util.Scanner; //allows the user to take an input
public class EnterMyName {

	//main method
    public static void main (String args[]) {

    Scanner input = new Scanner(System.in); //allows the user to take an input

    //delcare variables
    String name = "NICOLE";
	Date d = new Date(); //declare a variable called 'd' to hold the date

	//print the date
	System.out.println(d);
	//prompt the user
    System.out.println("Enter your name:");
    //take input
    name = input.next();
    System.out.println("My name is" + name + " \nWelcome" ); // \n is a new line

    //add surname to the name (change the value of name)
    name = "nicole campbell";

    System.out.println("Hello " + name);

    }//end main method


}//end class