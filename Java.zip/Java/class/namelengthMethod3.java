import java.io.*;
import java.util.*;
public class namelengthMethod3 {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
	String name = "Nicole";
    	namelength(name);
    }//end main method

    public static void namelength(String mname){
    	 for(int i = 0; i<=mname.length(); i++){
    		 System.out.println("*");
	 	}
    }//end



}