/**
 * @(#)dobcheck.java
 *take 5 date of birth in from the user in the format dd/mm/yyyy(as a string)
 *Pass this string to a method to check if the date of birth is vaild.
 *when it is valid return it and store it in an array
 *
 * @author
 * @version 1.00 2015/10/16
 */
import java.io.*;
import java.util.*;
public class dobcheck {
	static Scanner kbReader = new Scanner(System.in);
    public static void main (String args []) {

    	Date d = new Date();

    	String dob;
    	//string array to hold the date of birth in a string format
    	String dateofbirth[] = new String[5];

    	System.out.println(d);

    	//take in date of births
    	for(int i =0; i<dateofbirth.length; i++){
    		System.out.println("Enter dob (dd/mm/yyyy) : ");
    		dob = kbReader.nextLine();
    		//dobcheck method call
    		dateofbirth[i] = dobcheckmethod(dob);
    	}//end for loop
    	//print out the date of births
    	for(int i = 0; i<dateofbirth.length; i++){
    		System.out.println(dateofbirth);
    	}//end for loop
    }//end main method

    public static String dobcheckmethod(String mdob){
    	boolean flag = false;
    	char check1, check2;

    	while(flag == false){
    		//check dob format
    		if (mdob.length() != 10){
    			System.out.println("Invalid format\nPlease re-enter (dd/mm/yyyy : ");
    			mdob = kbReader.next();
    		}//end if
    		else{ //if it is length 10
    			//check where / are
    			check1 = mdob.charAt(2);
    			check2 = mdob.charAt(5);

    			if((check1 == '/') && (check2 == '/')){
    				flag = true; // change flag to true (its the correct format)
    			}//end if
    			else{
    				System.out.println("Invalid format\nPlease re-enter (dd/mm/yyyy : ");
    				mdob = kbReader.next();
    			}//end else

    		}//end out else
    		//if correct format change flag to true
    		//else
    		//re enter dob
     	}//end while
     	return mdob;
    }//end dobcheckmethod


}//end class