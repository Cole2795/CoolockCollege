import java.io.*;
import java.util*.;
public class Age{

	public static void main (String args []){
		Scanner kbReader = new Scanner(System.in);
		int age;
		System.out.println("Please enter your age : ");
		age = kbReader.nextInt();
		
		checkage(age);
	}	
	public static void checkage(int mage){

		if(mage>17){
			System.out.println("You can vote");
		}
		else{
			System.out.println("You can not vote yet");
	}
}