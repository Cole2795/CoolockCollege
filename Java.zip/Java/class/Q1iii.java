/**
 * @(#)Q1iii.java
 *take an age in from the user as a string (to validate, i.e checkit is number only)
 *check if the user is old enoughr to vote
 *
 * @author
 * @version 1.00 2015/9/17
 */
import java.util.Scanner;

public class Q1iii {
	//main method
    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	String strage;
    	int age =0;

    	System.out.println("Enter age :");
		strage = kbReader.nextLine();
		//check that strage only contains digits
		while(!strage.matches("\\d+"))//while strage does not match digit only
		{
			System.out.println("Error, numbers only");
			//prompt the user for the age
			System.out.println("Enter age :");
			strage = kbReader.nextLine();
		}//end while

		//change strage to an int
		age = Integer.parseInt(strage);

		//check if the user can vote
		if (age >=18)
		{
			System.out.println("You can vote");
		}
		else
		{
			System.out.println("You cannot vote yet");
		}
    }//end main method


}//end class