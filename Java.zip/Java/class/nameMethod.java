/**
 * @(#)nameMethod.java
 *Write a program that will call a method which will print your name 10 times
 *
 * @author
 * @version 1.00 2015/10/8
 */
import java.io.*;
import java.util.*;
public class nameMethod {

    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	String name;
    	System.out.println("Please enter your name:");
    	name = kbReader.nextLine();

    	method(name);
    }

    public static void method(String mname){

    	for(int i =0; i<10; i++){
    		System.out.println("Hello " + mname);
    	}
    }//end method


}//end class