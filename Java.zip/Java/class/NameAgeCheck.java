/**
 * @(#)NameAgeCheck.java
 *take in 5 names and grades display the highest lowest and average grade
 *store the names and grades in arrays
 *check for non digit
 * @author
 * @version 1.00 2015/10/1
 */

import java.io.*;
import java.util.*;
public class NameAgeCheck {
	//main method
    public static void main (String args []) {

    Scanner kbReader = new Scanner(System.in);
    String names [] = new String[5];

    int grades [] = new int[5];
    int high = 0, low = 100, total = 0;
    String strgrade, highname ="", lowname=""; //need to take in the grades as a String and Validate it

    //loop to take in the name and grades
    for(int i = 0; i<names.length; i++){
    	System.out.println("Enter name : ");
    	names[i] = kbReader.nextLine();
    	//prompt for grade
    	System.out.println("Enter grade for " + names[i] + " :");
    	strgrade = kbReader.nextLine();

    	//validate (check for digits only) strgrade
    	while(!strgrade.matches("\\d+")){
    		System.out.println("Error, digits only");
			//prompt for grade
    		System.out.println("Enter grade for " + names[i] + " :");
    		strgrade = kbReader.nextLine();
    	}//end while

    	//change strgrade to a digit
    	grades[i] = Integer.parseInt(strgrade);

    	//check for highest
    	if(grades[i]>high){ //if grades[i] is greater than high
    		high = grades[i]; //assign the value of grades[i] to high
    		highname = names[i];  // hold onto the name of the person who got the highest grade
    	}//end if

    	if(grades[i]<low){  //if grades[i] is less than low
    		low = grades[i]; //assign the value of grades[i] to low
    		highname = names[i]; // hold onto the name of the person who got the lowest grade
    	}//end if

    	//add grades[i] to the total
    	total += grades[i];

    } //end for

    System.out.println("Average grade is : " + total/grades.length);
    System.out.println("The highest is " + high + " achieved by " + highname);
    System.out.println("The lowest is " + low + " achieved by " + lowname);

    }//end method


}//end class