/**
 * @(#)Q3i.java
 *
 *
 * @author
 * @version 1.00 2015/9/23
 */

import java.io.*;
import java.util.*;
public class Q3i {

    public static void main(String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	int grade;

    	//prompt user for grade
    	System.out.println("Please enter your grade");
    	grade = kbReader.nextInt();
    	//take in the grade
    	if(grade>79){
    		System.out.println("Distinction");
    	}
    	else if(grade>64){
    		System.out.println("Merit");
    	}
    	else if(grade>49){
    		System.out.println("Pass");
    	}
    	else{
    	}
    		System.out.println("Unsuccessful");
    	}


    }//end method


}//end class