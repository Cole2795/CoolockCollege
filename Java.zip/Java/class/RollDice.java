/**
 * @(#)RollDice.java
 *roll dice using a method
 *
 * @author
 * @version 1.00 2015/10/1
 */


public class RollDice {

    public static void main (String args []) {

    	roll_dice();

    }//end main method

    public static void roll_dice(){
    	System.out.println(1 + (int)(Math.random()*6));
    }//end roll_dice me

}//end class