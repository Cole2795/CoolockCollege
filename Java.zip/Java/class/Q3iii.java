/**
 * @(#)Q3iii.java
 *
 *
 * @author
 * @version 1.00 2015/9/24
 */

import java.io.*;
import java.util.*;
public class Q3iii {
	//main method
    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	int numbers[] = {1,2,3,4,5};


    	for(int i =0;i<numbers.length;i++){
    		numbers[i] = numbers[i] * numbers[i];
    		System.out.println(numbers[i]);
    	}//end for
    }//end method


}//end class