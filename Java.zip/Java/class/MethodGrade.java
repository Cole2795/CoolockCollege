/**
 * @(#)MethodGrade.java
 *take grade from the user and pass it to a method
 *The method should tell the user if it is a distinction, Merit, Pass or Unsuccessful
 *
 * @author
 * @version 1.00 2015/10/2
 */
import java.io.*;
import java.util.*;
public class MethodGrade {

    public static void main (String args []) {

		Scanner kbReader = new Scanner(System.in);
		int grade;
		System.out.println("Enter grade");
   	 	grade = kbReader.nextInt();
    	method_grade(grade); //method name is method_grade and pass grade to the method

    }//end method

    public static void method_grade(int x){

  	  if(x > 79){
    	System.out.println("Distinction");
    	}
    	else if(x > 64){
    		System.out.println("Merit");
    	}
    	else if(x > 49){
    		System.out.println("Pass");
    	}
    	else{
    		System.out.println("Unsuccessful");
    	}
    }//end grade

}