/**
 * @(#)myName.java
 *Nicole Campbell
 *
 *delcare a variable to hold your name and prin "Hello I am ________"
 * @author
 * @version 1.00 2015/9/16
 */


public class myName {

	//main method
    public static void main (String args []) {

    	//delcare my name
    	String myname = "Nicole";

    	//print our name
    	System.out.println("Hello I am " + myname);

    }//end main method


}//end class