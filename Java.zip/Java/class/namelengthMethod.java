/**
 * @(#)namelengthMethod.java
 *pass your name to the method which will print the number of characters in your name
 *
 * @author
 * @version 1.00 2015/10/8
 */
import java.io.*;
import java.util.*;
public class namelengthMethod {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	//String name = "Nicole";
       	namelength("Nicole"); //prompt name and method 
    }//end main method

    public static void namelength(String x){ 
    	 //print out name of number of the character
    	 System.out.println(x + " has " + x.length() + " characters"); 
    }



}