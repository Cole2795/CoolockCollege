/**
 * @(#)animal.java
 *Create an animal class with name & colour
 *Create a landanimal with numlegs and type
 *Create a wateranimal with size and speed
 *Create an an array of animals made up of an animal, landanimal & wateranimal
 *
 * @author
 * @version 1.00 2016/2/26
 */


public class animal {

	private String name, colour;

    public animal(String name, String c) {
    	this.name = name;
    	this.colour = c;
    }//end animal

    public String toString(){
    	return "\nName: " + name + "\nColour: " + colour;
    }//end toString


}//end class