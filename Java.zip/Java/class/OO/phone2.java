/**
 * @(#)phone2.java
 *Create a phone object with instance variables number and make.
 *Create a student object. A Student has a phone and name and id.
 *Create an undergraduate-student which is a student but also have course name and course length.
 *Create a postgraduate-student which is a student but also has degree-type and grade.
 *Create a Test class and take in values from the user to create an array of students made up of postgraduate-student and an undergraduate students.
 *The user will need to be asked is the student a postgraduate or undergraduate.
 *Display all details of the students. Keep track of many students are being created.
 *
 * @author
 * @version 1.00 2016/3/3
 */


public class phone2 {
	private int number;
	private String make;

    public phone2(int n, String m) {
    	this.number = ((n>0)?n:111);
    	this.make = m;
    }//end constructor

    public String toString(){
   		return "\nNumber: " + number + "\nMake: " + make;
    }//end toString

}//end class