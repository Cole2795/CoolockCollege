/**
 * @(#)Office.java
 *Create an office object. An office has a location, phone_number and worker
 *Create a worker object with attributes name, id and salary
 *
 *In the OfficeTest create array of office objects, length 3.
 *printer the details of the office objects
 *
 * @author
 * @version 1.00 2016/2/5
 */


public class Office {
	private String location;
	private int phone_number;
	private worker w1;

    public Office(String location, int phone_number, worker w) {
    	this.location = location;
    	this.phone_number = phone_number;
    	w1 = w;

    }//end constructor

    public String toString(){
    	return "\nLocation: " + location + "\nPhone Number: " + phone_number + w1.toString();
    }//end toString


}//end class