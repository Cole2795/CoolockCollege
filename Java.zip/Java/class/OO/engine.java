/**
 * @(#)engine.java
 *Create an engine class with attributes types (petrol/diesel) and size leg 1000, 2000).
 *
 *
 * @author
 * @version 1.00 2016/1/21
 */


public class engine {

	private String type;
	private int size;

    public engine(String t, int s) {

    	this.type = t;
    	this.size = ((s>0)?s:1);

    }//end engine

    public void setenginesize(int s){
    	this.size = ((s>0)?s:1);
    }//end setenginesize

    public int getenginesize(){
    	return size;
    }//end getenginesize

    public String toString(){
    	return "\nFuel Type : " + type + "\nSize : " + size;
    }//end toString


}//end class