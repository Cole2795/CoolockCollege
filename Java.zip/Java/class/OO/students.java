/**
 * @(#)students.java
 *Create a student object. A Student has a phone and name and id.
 *
 * @author
 * @version 1.00 2016/3/3
 */


public class students{
	private static int counter = 0;
	private String name;
	private int id;
	private phone2 p1;

    public students(String na, int i, phone2 p1) {
    	this.name = na;
    	this.id = ((i>0)?i:111);
    	this.p1 = p1;
    }//end constructor

	public int getcount(){
		return counter;
	}//end getcount

    public String toString(){
    	return "\nName: " + name + "\nID: " + id + p1.toString();
    }//end toString


}//end class