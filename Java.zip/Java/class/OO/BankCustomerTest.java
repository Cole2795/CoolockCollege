/**
 * @(#)BankCustomerTest.java
 *
 *
 * @author
 * @version 1.00 2015/12/11
 */


public class BankCustomerTest {

    public static void main (String args []) {

    	//create customer with all details
    	BankCustomer bc1 = new BankCustomer("Nicole", "Dublin", 100,1123, false);
    	//Bankcustomer with only name and account number know
    	BankCustomer bc2 = new BankCustomer("Fred", 3454);
    	//bankCustomer with name, address and account number
    	BankCustomer bc3 = new BankCustomer("Shane", "Meath", 4332);

    	System.out.println(bc1.toString());
		System.out.println(bc2.toString());
		System.out.println(bc3.toString());

    }//end main method


}//end class