/**
 * @(#)buildingTest.java
 *
 *
 * @author
 * @version 1.00 2016/1/28
 */
import java.io.*;
import java.util.*;
public class buildingTest {

    public static void main(String args[]) {
		Scanner kbReader = new Scanner(System.in);

		String blocation, bname;
		int bsize, bnumfloor, bcapacity;

		System.out.println("Enter name: ");
		bname = kbReader.nextLine();
		System.out.println("Enter capacity (number of people): ");
		bcapacity = kbReader.nextInt();
		System.out.println("Enter Location: ");
		blocation = kbReader.next();
		System.out.println("Enter Square meters: ");
		bsize = kbReader.nextInt();
		System.out.println("Enter number of floor: ");
		bnumfloor = kbReader.nextInt();


		school s1 = new school(blocation, bsize, bnumbfloor, bname, bcapacity);
		System.out.println(s1.toString());

		/*school s1 = new school("Coolock", 4, 9000, "CDCFE", 1200);

		System.out.println(s1);
		System.out.println("Location is " + s1.toString());
		s1.setlocation("Dublin 17");
		System.out.println("New Location is " + s1.getlocation());

		building b1 = new building("Santry", 2,2000);
		System.out.println(b1);

		System.out.println("location is " + b1.getlocation());*/

    }//end main method


}//end class