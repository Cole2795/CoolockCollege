/**
 * @(#)school.java
 *Create a school object. A school is a building but also has a name and capacity (number of people)
 *
 * @author
 * @version 1.00 2016/1/28
 */


public class school extends building {
	private String name;
	private int capacity;

    public school(String location, int size, int numbfloor, String name, int capacity) {
    	super(location, size, numbfloor);
    	this.name = name;
    	this.capacity = ((capacity>0)?capacity:1);

    }//end constructor

    public String toString(){
    	return "\nName: " + name + "\nCapacity: " + capacity + super.toString();
    }//end toString


}//end class