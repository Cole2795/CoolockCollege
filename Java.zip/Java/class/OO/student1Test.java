/**
 * @(#)student1Test.java
 *
 *
 * @author
 * @version 1.00 2016/1/8
 */


public class student1Test {

    public static void main(String args[]) {


    	//create student
    	student1 s1 = new student1("Nicole", 111,c1);
		//create college object
    	college c1 = new college("CDCFE", "Coolock",30);
    	System.out.println(s1);


    }//end main method


}