/**
 * @(#)car.java
 *create an engine class with attributes types (petrol/diesel) and size leg 1000, 2000).
 *Create a class with attributes make, model and engine.
 *In the carTest take all input from the user and create a car.
 *In the engine and care class use setdetails method to set the attributes and not the constructor.
 *
 * @author
 * @version 1.00 2016/1/21
 */


public class car {
	private String make, model;
	private engine e1;

   	public car(String ma, String ml, engine e){

		make = ma;
    	model = ml;
   		e1 = e;
   	}//end car

	public void setengineSize(int s){
		e1.setenginesize(s);
	}//end setengineSize

	public int getengineSize(){
		return e1.getenginesize();
	}//end getengineSize

	public String toString(){
	return "\nCar Details\nMake : " + make + "\nModel : " + model + e1.toString();
	}//end toString

}//end class



