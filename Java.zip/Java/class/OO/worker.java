/**
 * @(#)worker.java
 *Create a worker object with attributes name, id and salary
 *
 * @author
 * @version 1.00 2016/2/5
 */


public class worker {
	private String name;
	private int id, salary;

    public worker(String name, int id, int salary) {
    	this.name = name;
    	this.id = ((id>0)?id:1);
    	this.salary = ((salary>0)?salary:111);

    }//end worker

    public String toString(){
    	return "\nDetails Office\nName: " + name + "\nID: " + id + "\nSalary: " + salary;
    }//end toString

}//end class