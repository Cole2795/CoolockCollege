/**
 * @(#)phone1.java
 *
 *
 * @author
 * @version 1.00 2016/1/14
 */


public class phone1 {
	private int number, ring_volume;
	private String colour;

    public phone1(int n, int rv, String c) {
    	this.number =((n>0)?n:123);
    	ring_volume = ((rv>0 && rv<10)?rv : 1);
        colour = c;


    }

    public String toString(){
    	return "\n\nPhone Details\nNumber : " + number + "\nring_volume : " + ring_volume + "\nColour : " + colour;

    }//end toString


}//end class