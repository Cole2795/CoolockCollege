/**
 * @(#)time.java
 *Create a time object that can be set with knowing
 *no arguments
 *hour
 *hour and minute
 *hour and minute and second
 *time object
 *
 * @author
 * @version 1.00 2015/12/11
 */


public class time {
	private int hour, minute, second;

	//constructor with no argument
    public time() {
    	setDetails(0,0,0);
    }

    //constructor with hour argument
    public time (int h){
    	setDetails(h,0,0);
    }//end time h

    //constructor with hour, minute argument
    public time(int h, int m){
    	setDetails(h,m,0);
    }//end time h,m

	//constructor with hour, minute and second argument
    public time(int h, int m, int s){
    	setDetails(h,m,s);
    }//time h,m,s

    //public time(time t){
    //	setDetails(t.gethour(), t.getminute(), t.getsecond());
    //}

    public void setDetails(int h, int m, int s){
    	hour = ((h>=0&& h<24)?h :0);
    	minute = ((m>=0&& m<59)?m :0);
    	second = ((s>=0&& s<59)?s :0);
    }//end setDetails

    public String toString(){
    	return "Time is : " + hour + ":" + minute + ":" + second;
    }//end toString


}//end class