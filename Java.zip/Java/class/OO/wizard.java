/**
 * @(#)wizard.java
 *
 *
 * @author
 * @version 1.00 2016/1/22
 */


public class wizard extends character {
	private String power, hat_color;

    public wizard(String name, int speed, double height, String power, String hat_color){
    	super(name, speed, height);
    	this.power = ((power.length()>0)?power: "Secret");
    	this.hat_color = hat_color;
    }//end constructor

    public String toString(){
    	return super.toString() + "\nPower: " + power + "\nHatcolor: " + hat_color;

    }//end Character
}//end class