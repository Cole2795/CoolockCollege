/**
 * @(#)student2.java
 *Create a student object with attributes collegeName and CourseName
 *A student is a person
 *have set get methods. have a studies behavior (method) that will have a number of hours passed to it and
 *will return "name studies numhours per day"
 *
 * @author
 * @version 1.00 2016/1/31
 */


public class student2 extends Aperson {
	private String collegeName, courseName;

    public student2(String name, String address, int id, String collegeName, String courseName){
    	super(name, address, id);
    	this.collegeName = collegeName;
    	this.courseName = courseName;

    }//end constructor

    public void setcollegeName(String collegeName){
    	this.collegeName = collegeName;
    }

    public String getcollegeName(){
    	return collegeName;
    }

    public void setcourseName(String courseName){
    	this.courseName = courseName;
    }

    public String getcourseName(){
    	return courseName;
    }

    public String toString(){
    	return super.toString() + "\nCollege Name: " + collegeName + "\nCourse Name: " + courseName;
    }//end toString



}//end class