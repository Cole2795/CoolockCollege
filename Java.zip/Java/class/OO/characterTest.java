/**
 * @(#)characterTest.java
 *
 *
 * @author
 * @version 1.00 2016/1/22
 */


public class characterTest {

    public static void main (String args []) {
    	//soldier
    	soldier s1 = new soldier("Charlie", 12, 1.6, 123, "Sgt.");
    	System.out.println(s1.toString());

    	System.out.println("Number of characters are: " + s1.getcount());

    	//wizard
    	wizard w1 = new wizard("Keith", 14, 2.1, "everything", "Red");
		System.out.println(w1.toString());
    	System.out.println("Number of characters are: " + w1.getcount());

    }//end main method


}//end class