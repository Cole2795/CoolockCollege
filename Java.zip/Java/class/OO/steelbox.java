/**
 * @(#)steelbox.java
 *
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class steelbox extends box {

    public steelbox() {

    }

    public void info(){
    	System.out.println("This is a standard steel box");
    }


}