/**
 * @(#)ApersonTest.java
 *Have a test class and create a student object
 *call the studies behaviour and the toString method. Change the CollegeName
 *and classname and print the new details using get methods.
 *
 *
 * @author
 * @version 1.00 2016/1/31
 */
//import java.io.*;
//import java.util.*;
public class ApersonTest {

    public static void main(String args[]) {
    	Aperson p1 = new Aperson("Nicole", "Dublin", 123);
    	student2 s1 = new student2("Stephen","Meath", 345, "Coolock collge", "art");

    	System.out.println(p1);
		System.out.println(s1);
		System.out.println(s1.studies(15));

    }//end main method


}//end class