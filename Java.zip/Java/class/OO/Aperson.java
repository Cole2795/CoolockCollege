/**
 * @(#)Aperson.java
 *Create a person object with attributes name, address and id.
 *have set and get method
 *Create a student object with attributes collegeName and CourseName
 *A student is a person
 *have set get methods. have a studies behavior (method) that will have a number of hours passed to it and
 *will return "name studies numhours per day"
 *Have a test class and create a student object
 *call the studies behaviour and the toString method. Change the CollegeName
 *and classname and print the new details using get methods.
 *
 * @author
 * @version 1.00 2016/1/28
 */


public class Aperson {
	private String name, address;
	private int id;

    public Aperson(String n, String a, int i) {
    	this.name = n;
    	this.address = a;
    	this.id = ((i>0)?i:0);


    }//end constructor

    public void setname(String n){
    	this.name = n;
    }

    public String getname(){
    	return name;
    }

    public void setaddress(String a){
    	this.address = a;
    }

	public String getaddress(){
		return address;
	}

	public void setid(int i){
			id = ((i>0)?i:0);
	}

	public int getid(){
		return id;
	}

	public String studies(int x){
		return name + " studies " + x + " hours per Week";
	}

	public String toString(){
		return "\nName: " + name + "\nAddress: " + address + "\nID: " + id;
	}//end toString

}//end class