/**
 * @(#)phone.java
 *create a phone object with instance variables, make, colour and number
 *Have a toSrting method
 *create a phoneTest and create a valid and invalid instance of phone
 * @author
 * @version 1.00 2015/12/3
 */


public class phone {
	//attribute
	private String make;
	private String colour;
	private int number;

	//constructor  (the purpose of the constructor is to create an object in a consistant state
    public phone(String make, String colour, int number){
    	this.make = ((make.length()>0)?make : "unknown");
    	this.colour = ((colour.length()>0)?colour : "unknown");
    	this.number =((number>0)?number : 1);

    }//end constructor

    //toString
    public String toString(){
    	return "\nMake : " + make + "\nColour : " + colour + "\nNumber : " + number;

    }//end toString

}//end class