/**
 * @(#)employeeTest.java
 *
 *
 * @author
 * @version 1.00 2015/12/10
 */
import java.io.*;
import java.util.*;
public class employeeTest {

    public static void main(String args []) {

    	Scanner kbReader = new Scanner(System.in);

    	String name1, name2;
    	int id1, id2, numhours1, numhours2;

		//employee 1
    	System.out.println("Please enter name 1 : ");
    	name1=kbReader.nextLine();
    	System.out.println("id 1: ");
    	System.out.println("Please enter id " + name1 + " : ");
    	id1=kbReader.nextInt();
    	System.out.println("Numhours 1: ");
    	System.out.println("Please enter numhours " + name1 + " : ");
    	numhours1=kbReader.nextInt();

		//employee 2
    	System.out.println("Please enter name 2 : ");
    	name2=kbReader.next();
    	System.out.println("id 2: ");
    	System.out.println("Please enter id " + name2 + " : ");
    	id2=kbReader.nextInt();
    	System.out.println("Numhours 2: ");
    	System.out.println("Please enter numhours " + name2 + " : ");
    	numhours2=kbReader.nextInt();

		//declareemployee details
    	employee e1 = new employee(name1, id1, numhours1);
		employee e2 = new employee(name2, id2, numhours2);


		//print all object details
		System.out.println("\nAll details of Employee : ");
		System.out.println(e1.toString());
		System.out.println(e2.toString());

		//change values of employee e2
		e2.setname("Mr. Jones");
		e2.setid(321);
		e2.setnumhours(39);

		//diplay new details for e2 using get method
		System.out.println("\nNew details for employee 2 : " );
		System.out.println("Name : " + e2.getname());
    	System.out.println("ID : " + e2.getid());
    	System.out.println("Number of hours : " + e2.getnumhours());

    	System.out.println("\nWages : ");
    	System.out.println(e1.getname() + "'s Wages : " + e1.calculateWages(10.75));
    	System.out.println(e2.getname() + "'s Wages : " + e2.calculateWages(10.75));

    }//end method


}//end class