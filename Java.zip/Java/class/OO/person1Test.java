/**
 * @(#)person1Test.java
 *
 *
 * @author
 * @version 1.00 2016/1/14
 */


public class person1Test {

    public static void main(String args[]) {

    	//create phone1
    	phone1 p1 = new phone1(123,4,"red");
		person1 prsn1 = new person1("Nicole", 20, "Soccer", p1);

		System.out.println(prsn1.toString());

    }//end method


}//end class