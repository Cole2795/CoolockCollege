/**
 * @(#)person1.java
 *Create a personal object with attributes name, age, hobby and phone1 object.
 *The Phone1 object should have a number, ring_volume and colour.
 *Create a person1Test with a valid instance of a person1 object
 *
 * @author
 * @version 1.00 2016/1/14
 */


public class person1 {
	private String name;
	private int age;
	private String hobby;
	private phone1 p1;

    public person1(String n, int a, String h, phone1 p) {
    	name = n;
    	age = ((a>0)?a:1);
    	hobby = h;
    	p1 = p;

    }//end person1

    public String toString(){

    	return "\nName : " + name + "\nAge : "+ age + "\nHobby : " + hobby + p1.toString();

    }//end toString


}//end class