/**
 * @(#)Employee1.java
 *Create an employee object with name, id, salary and grade (1-4)
 *Use a SetDetails methods to set the attributes and not the construcotr
 *have a bonus method that will calculate the employees bonus which is 5% of their salary
 *take values in from the user
 *create a valid and invalid instance of employee
 * * @author
 * @version 1.00 2016/2/4
 */


public class Employee1 {
	//attribute
	private String name;
	private int id, salary, grade;

	//blank constructor
	public Employee1(){

	}

	//constructor with name and id known
	public Employee1(String name, int id){
		setDetails(name,id,0,0);
	}

	//constructor with all details known
	public Employee1(String name, int id, int salary, int grade) {
		setDetails(name,id,grade,salary);
	}

    public void setDetails(String name, int id, int grade, int salary) {

    	this.name = ((name.length()>0)?name:"Unknown");				//this.name = name;
    	this.id = ((id>0)?id:0);
    	this.grade = ((grade>0 && grade<5)?grade:1);
		this.salary = ((salary>0)?salary:111);
    }//end constructor

	public String getname(){
		return name;
	}

    /*public int getid(){
		return id;
	}

	public int getsalary(){
		return salary;
	}

   	public int getgrade(){
		return grade;
	}*/

	public double getbonus(){
		return salary *.05;//5% of salary
	}



	public String toString(){
		return "\nName: " + name + "\nID: " + id + "\nGrade: " + grade + "\nSalary: " + salary ;
	}//end toString

}//end class