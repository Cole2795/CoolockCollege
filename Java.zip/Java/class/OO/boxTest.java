/**
 * @(#)boxTest.java
 *
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class boxTest {

    public static void main(String args[]) {

    	//create a box object
    	box b1 = new box();
     	box b3 = new WoodenBox();
     	box b4 = new steelbox();
     	box b5 = new LargeSteelBox();


    	b1.info();
    	b3.info();
    	b4.info();
    	b5.info();
    }//end main


}