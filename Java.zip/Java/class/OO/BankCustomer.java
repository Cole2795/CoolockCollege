/**
 * @(#)BankCustomer.java
 *Have a bank customer with name, account number, balance, address and overdraft
 *Create a Customer with all details
 *Create a Customer with only name and account number
 *
 * @author
 * @version 1.00 2015/12/11
 */


public class BankCustomer {
	private int balance, account_number;
	private String name, address;
	private boolean overdraft;

    public BankCustomer(String n, String a, int b, int ac, boolean od) {
    	name = ((n.length()>0)?n:"Unknown");
    	address = ((a.length()>0)?a:"Unknown");
    	balance = b;
    	account_number= ac;
       	overdraft = od;

    }//end contructor

    //constructor with name and account number only
    public BankCustomer(String n, int ac){
    		name = ((n.length()>0)?n:"Unknown");
    		address = "Unknown";
    		balance = 0;
    		account_number = ac;
    		overdraft = false;

    }//end name and account

    //constructor with with name, address and account number
     public BankCustomer(String n, String a, int ac){
     	name = ((n.length()>0)?n:"Unknown");
    		address = ((a.length()>0)?a:"Unknown");
    		balance = 0;
    		account_number = ac;
    		overdraft = false;
     }


    public String toString(){
    	return "\nName : " + name + "\nAddress : " + address + "\nAccount number : " + account_number + "\nBalance : " + balance + "\nOverdraft : " + overdraft;

    }//end toSrring

}//end class