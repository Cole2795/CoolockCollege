/**
 * @(#)Computer.java
 *Create a memory object with attributes manufacturer, size (gb)
 *
 *Create a computer object with attributes make, model and memory
 *Have a computerTest class and create a computer object.
 *Take all instance variables in form the user.
 *
 * @author
 * @version 1.00 2016/1/14
 */


public class Computer {

	private String make, model;
	private memory m1;

    public Computer(String ma, String ml, memory m) {
    	make = ma;
    	model = ml;
    	m1 = m;

    }//end Computer

	public void setmemorySize(int s){
		m1.setmemorysize(s);
	}

	public int getmemorySize(){
		return m1.getmemorysize();
	}
    public String toString(){

    	return "\nMake : " + make + "\nModel : " + model + m1.toString();

    }//end toString

}//end class