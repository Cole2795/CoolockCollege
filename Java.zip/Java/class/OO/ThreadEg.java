/**
 * @(#)ThreadEg.java
 *
 *
 * @author
 * @version 1.00 2016/1/28
 */


public class ThreadEg {

    public static void main(String args[]) {

    String sentence = "Welcome to my java programming class in room 203";
    char mychar;
    String mysentence = "";

    try {
    	for (int i =0; i<sentence.length();i++){

    		Thread.currentThread().sleep(100);
    		mychar = sentence.charAt(i);
    		mysentence += mychar;
    		//System.out.println("\r " + mysentence);
    		printing(mysentence);
    	}//end for

    }//end try
    catch(Exception e){
    	System.out.println("Cannot find data required");
    }//end catch

	System.out.println();

    }//end main method

	public static void printing(String x){
		System.out.print("\r " + x);
	}//end printing


}//end class