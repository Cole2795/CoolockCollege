/**
 * @(#)college.java
 *
 *
 * @author
 * @version 1.00 2016/1/8
 */


public class college {
private String name, address;
private int numcourses;

    public college(String name, String address, int nc ) {
    	this.name = name;
    	this.address = address;
    	numcourses = ((nc>0)?nc:1);
    }

    public String toString(){
    	return "\nCollege Details\nName : " + name + "\nAddress : "+ address + "\nNumber of courses : " + numcourses;
    }

}