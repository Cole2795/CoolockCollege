/**
 * @(#)studentsTest.java
 *
 *
 * @author
 * @version 1.00 2016/3/4
 */
import java.io.*;
import java.util.*;
public class studentsTest {

    public static void main(String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	String make, name, coursename, grade , postgraduate, undergraduate, graduate;
    	int number, id, courselength, degreetype;
    	int choice;

		int numstudents;

    	students s[] = new students[3];

		phone2 p1 = new phone2(467777, "Iphone");
    	s[0] = new students("Nicole",23,p1);
    	s[1] = new undergraduatestudent("Keith", 343, p1, "computer", 5);
    	s[2] = new postgraduatestudent("Ashley", 654, p1, 50, "Merit");

    	for (int i = 0;i<s.length;i++){
    		System.out.println("\nStudent Details " + (i+1));
    		System.out.println(s[i].toString());
    	}//end for

    	System.out.println("Enter number of students: ");
    	numstudents = kbReader.nextInt();

    	students s1[] = new students[numstudents];

    	for(int i = 0;i<s1.length;i++){

		choice =0;
		while(choice != 2){
    	System.out.println("Please choice an option: ");
    	System.out.println("1. Postgraduate");
    	System.out.println("2. Undergrauate");
			choice = kbReader.nextInt();


    	if(choice == 1){
    		System.out.println("You choose Postgraduate");
    		System.out.println("Please enter name: ");
    		name = kbReader.next();

    		System.out.println("please enter id: ");
    		id = kbReader.nextInt();

    		System.out.println("please enter make: ");
    		make = kbReader.next();

    		System.out.println("please enter number: ");
    		number = kbReader.nextInt();

    		//phone2 p1 = new phone(make, number);
    		//phone 2 p1[] = new phone2[2];

    		System.out.println("please enter course Length: ");
    		courselength = kbReader.nextInt();

    		System.out.println("please enter grade: ");
    		grade = kbReader.next();

    	}
    	else if(choice == 2){
    		System.out.println("You choose Undgraduate");
    		System.out.println("Enter name:");
    		name = kbReader.next();

    		System.out.println("please enter id: ");
    		id = kbReader.nextInt();

    		System.out.println("please enter make: ");
    		make = kbReader.next();

    		System.out.println("please enter number: ");
    		number = kbReader.nextInt();


    		//phone2 p1 = new phone(make, number);
    		//phone 2 p1[] = new phone2[2];

    		System.out.println("please enter course name: ");
    		coursename = kbReader.next();

    		System.out.println("please enter degree type: ");
    		degreetype = kbReader.nextInt();

    		System.out.println("College Details:\nName : " + name + "\nID: " + id + "\nPhone make: " + make + "\nPhone number: " + number + "\ncourse: " + coursename + "\nDegree type: " +  degreetype);
    	}
    	else{
    		System.out.println("no number from option, only 1 to 2");
    	}


	}//end for
}//end while
			//details needed for all students
    		/*System.out.println("Please enter name: ");
    		name = kbReader.next();

    		System.out.println("please enter id: ");
    		id = kbReader.nextInt();

    		//System.out.println("Please enter number: ");
    		//number = kbReader.nextInt();

    		//System.out.println("Please enter make of your phone: ");
    		//make = kbReader.next();

			//create phone2
			phone2 p2 = new phone2(3456, "Sumsung");

			//details needed for undergraduate student
    		System.out.println("Please enter course name: ");
    		coursename = kbReader.next();

    		System.out.println("Please enter course length: ");
    		courselength = kbReader.nextInt();
			//set up undergraduate

			//details needed for postgraduate student*/



    }//end main method


}//end class