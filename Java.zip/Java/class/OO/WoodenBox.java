/**
 * @(#)WoodenBox.java
 *
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class WoodenBox extends box {

	private int numPlanks;

    public WoodenBox() {

    }

    public void info(){
    	System.out.println("This is a wooden box");
    }


}