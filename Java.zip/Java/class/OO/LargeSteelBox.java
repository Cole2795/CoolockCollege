/**
 * @(#)LargeSteelBox.java
 *
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class LargeSteelBox extends steelbox {

    public LargeSteelBox() {

    }

    public void info(){
    	System.out.println("This is a large steel box, it's very heavy!");
    }


}