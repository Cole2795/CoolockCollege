/**
 * @(#)aphone.java
 *
 *A phone object has a make, colour and an app
 * @author
 * @version 1.00 2016/2/4
 */


public class aphone {
	private String make, colour;
	private App a1;
    public aphone(String make, String colour, App a1) {

    	this.make = make;
    	this.colour = colour;
    	this.a1 = a1;

    }//end constructor

    public String toString(){
    	return "\nMake: " + make + "\nColour: " + colour + a1.toString();
    }//end toString

}//end class