/**
 * @(#)animalTest.java
 *
 *
 * @author
 * @version 1.00 2016/2/26
 */


public class animalTest {

    public static void main(String args[]) {
    	//Create the animal array object
    	animal an[] = new animal[3];
    	//populate array
    	an[0] = new animal("Nicole", "Red");
    	an[1] = new landanimal("Keith", "Orange", 4, "Sheperd");
    	an[2] = new wateranimal("Ashley", "Purple", 3, 45);

    	for(int i = 0;i<an.length;i++){
    		System.out.println("\nAnimal " + (i+1));
    		System.out.println(an[i].toString());
    	}//end for

    }


}//end class