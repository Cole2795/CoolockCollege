/**
 * @(#)building.java
 *Create a building object with attribute location, size, number_of_floor. Move set and get methods.
 *Create a school object. A school is a building but also has a name and capacity (number of people)
 *Create a school object in the test class and take inputs from the user.
 *
 * @author
 * @version 1.00 2016/1/28
 */


public class building {
	private String location;
	private int size;
	private int numbfloor;


    public building(String n, int s, int nf) {
    	this.location = n;		//((n>0)?n:"unknown");
    	this.size = ((s>0)?s:1);
    	numbfloor = ((nf>0)?nf:1);


    }//end constructor

    public void setlocation(String n){
    		this.location = n;
    }//end

    public String getlocation(){
    	return location;
    }

    //public static void setsize(int s){
    //	this.size = ((s>0)?s:1);
    //}

    public int getsize(){
    	return size;
    }

    //public static void setnumbfloor(int nf){
    //		number_of_floor = ((nf>0)?nf:1);
    //}

    public int getnumbfloor(){
    	return numbfloor;
    }

    public String toString(){
    	return "\nLocation: " + location + "\nSquare meters: " + size + "\nNumber of floor: " + numbfloor;
    }//end toStriing


}//end class