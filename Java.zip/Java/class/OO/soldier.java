/**
 * @(#)soldier.java
 *
 *
 * @author
 * @version 1.00 2016/1/22
 */


public class soldier extends character {
	private int number;
	private String rank;

    public soldier(String name, int speed, double height, int number, String rank) {
    	super(name, speed, height);	//calls the constructor of the super class (character)
    	this.number = ((number>0)?number :111);
    	this.rank = rank;

    }//end constructor

    public String toString(){
    	return super.toString() + "\nNumber: " + number + "\nRank: " + rank;
    }//end toString

}//end class