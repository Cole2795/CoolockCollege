/**
 * @(#)Employee1Test.java
 *
 *
 * @author
 * @version 1.00 2016/2/5
 */
import java.io.*;
import java.util.*;
public class Employee1Test {

      public static void main(String args []) {

		Scanner kbReader = new Scanner(System.in);
		String name;
		int id, salary, grade;

      	//create new new employee
      	Employee1 e1 = new Employee1("Nicole", 123, 1, 1111);
      	System.out.println(e1.toString());

		Employee1 e2 = new Employee1();
		e2.setDetails("Fred", 321, 22, 2222);
      	System.out.println(e2);


      	//create the object with only name and id known
      	Employee1 e3 = new Employee1("Stephen", 567);
      	System.out.println(e3);

      	System.out.println("Bonus Received: \n");
      	System.out.println(e1.getname() + "\t" + e1.getbonus());
      	System.out.println(e2.getname() + "\t" + e2.getbonus());
      	System.out.println(e3.getname() + "\t" + e3.getbonus());

      	//create an employee array
      	Employee1 employeeArray[] = new Employee1[3];
      	for(int i = 0;i<employeeArray.length;i++){
      		System.out.print("Enter name: ");
      		name = kbReader.next();
      		System.out.print("Enter id: ");
      		id = kbReader.nextInt();
      		System.out.print("Enter grade: ");
      		grade = kbReader.nextInt();
      		System.out.print("Enter salary: ");
      		salary = kbReader.nextInt();

      		//create object
      		employeeArray[i] = new Employee1(name, id, grade, salary);

      	}//end for

      	for(int i = 0;i<employeeArray.length;i++){
      		System.out.println(employeeArray[i].toString());
      	}//end for


    }//emd main method


}//end class