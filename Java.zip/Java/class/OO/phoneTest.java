/**
 * @(#)phoneTest.java
 *
 *
 * @author
 * @version 1.00 2015/12/3
 */


public class phoneTest {

    public static void main(String args[]) {

    	//create new phone object
    	phone p1 = new phone("Iphone", "Blue", 949023394);

    	phone p2 = new phone("", "", -2);

		System.out.println("Phone 1\n" + p1.toString());

    	System.out.println("\nPhone 2\n" + p2.toString());
    }//end main method


}//end class