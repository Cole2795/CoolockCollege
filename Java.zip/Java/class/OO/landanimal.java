/**
 * @(#)landanimal.java
 *
 *
 * @author
 * @version 1.00 2016/2/26
 */


public class landanimal extends animal {
	private int numlegs;
	private String type;

    public landanimal(String name, String c, int n, String t) {
    	super(name, c);
    	this.numlegs = ((n>0)?n:111);
    	this.type = t;

    }//end constructor
	public String toString(){
		return super.toString() + "\nNumlegs: " + numlegs + "\nType: " + type;
	}//end toString

}//end class