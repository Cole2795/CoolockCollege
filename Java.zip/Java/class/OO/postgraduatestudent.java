/**
 * @(#)postgraduatestudent.java
 *Create a postgraduate-student which is a student but also has degree-type and grade.
 *
 * @author
 * @version 1.00 2016/3/3
 */


public class postgraduatestudent extends students {
	private int degreetype;
	private String grade;

    public postgraduatestudent(String na, int i, phone2 p1, int d, String g) {
    	super(na, i, p1);
    	this.degreetype = ((d>0)?d:111);
    	this.grade = g;
    }//end constructor

    public String toString(){
    	return super.toString() + "\nDegree Type: " + degreetype + "\nGrade: " + grade;
    }//end toString


}//end class