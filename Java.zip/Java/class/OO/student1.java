/**
 * @(#)student1.java
 *Create a student1 object that has a name, id and college (college is an object)
 *- Create a college object with name, address and num_courses
 *In the test class create a student1 object and print the details (Create the college
 *object first)
 * @author
 * @version 1.00 2016/1/8
 */


public class student1 {
private String name;
private int id;
private college c1;

    public student1(String n, int i, college c) {
    	name = n;
    	id = ((i>0)?i:111);
    	c1 = c;
    }

    public String toString(){
    	return "\nName : " + name + "\nID : "+ id + c1.toString();
    }

}