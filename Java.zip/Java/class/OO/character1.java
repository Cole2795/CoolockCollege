/**
 * @(#)character1.java
 *create character1
 *wizard
 *character1Test
 * @author
 * @version 1.00 2016/1/22
 */


public class character1 {

    public character1() {
    }


}