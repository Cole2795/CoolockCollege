/**
 * @(#)BusinessCustomer.java
 *
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class BusinessCustomer extends PolyCustomer {

   private int id;
	private String PAname;

    public BusinessCustomer(String n, String a, int i, String p) {
    	super(n, a);
    	id = ((i>0)?i:111);
    	PAname = p;

    }//end constructor

    public String toString(){
    	return super.toString() + "\nID: " + id + "\nPersonal Assistant: " + PAname;
    }


}