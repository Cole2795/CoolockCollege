/**
 * @(#)phone2Test.java
 *
 *The user will need to be asked is the student a postgraduate or undergraduate.
 *Display all details of the students. Keep track of many students are being created.
 * @author
 * @version 1.00 2016/3/3
 */

import java.io.*;
import java.util.*;
public class phone2Test {

    public static void main(String args[]) {
    	Scanner kbReader = new Scanner(System.in);
    	String pgraduate;

       	phone2 p[] = new phone2[3];

    	p[0] = new students(467777, "Iphone", "Nicole", 23 );
    	p[1] = new undergraduatestudent(454940, "Sumsung", "Keith", 343, "computer", 5);
    	p[2] = new postgraduatestudent(34545, "Nokia", "Ashley", 654, 50, "Merit");

   		for (int i = 0;i<p.length;i++){
    		System.out.println("\nCollege " + (i+1));
    		System.out.println(p[i].toString());
    	}//end for

    	System.out.println("\nAre you postgraduate or undergradute: ");
		pgraduate = kbReader.nextLine();

		System.out.println(p[1].toString() + "\n" + pgraduate);
    }//end main method


}//end class