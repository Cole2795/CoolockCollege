/**
 * @(#)App.java
 *Create an app object with instance variables Name, size and numLevels
 *Create a phone object
 *A phone object has a make, colour and an app
 *Create a phoneTest class and print the details of the phone
 * * @author
 * @version 1.00 2016/2/4
 */


public class App {
	private String name;
	private int size, numlevels;

    public App(String name, int size, int numlevels) {
    	this.name = name;
    	this.size = ((size>100)?size:1000);
    	this.numlevels = ((numlevels>0)?numlevels:1);

    }//end constructor

    public String toString(){
    	return "\nApp Detail\nName: " + name + "\nSize: " + size + "\nNumlevels: " + numlevels;
    }//end toString

}//end class