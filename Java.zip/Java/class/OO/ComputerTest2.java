/**
 * @(#)ComputerTest2.java
 *Create an array of computer objects display all objects
 *
 * @author
 * @version 1.00 2016/1/15
 */
import java.io.*;
import java.util.*;
public class ComputerTest2 {

    public static void main(String args[]) {

    	Scanner kbReader = new Scanner(System.in);

    	String cmake, cmodel, manuf;
		int size;

    	int numcomps;

    	System.out.println("Enter the number of computer : ");
    	numcomps = kbReader.nextInt();

    	Computer comps[] = new Computer[numcomps];

    	//loop to initialise the arrays
    	for(int i = 0;i<comps.length;i++){


    			System.out.println("Enter memory manufacturer : ");
				manuf = kbReader.next();

				System.out.println("Enter computer manufacturer : ");
				cmake = kbReader.next();

				System.out.println("Enter computer model : ");
				cmodel = kbReader.next();

				System.out.println("Enter memory size : ");
				size = kbReader.nextInt();

				//create objects
		    	memory m1 = new memory(manuf,size);
				//memory m1 = new memory("DEll", 23);
				//comps[i] = new Computer("hp", "gds", m1);
				comps[i] = new Computer(cmake, cmodel, m1);

    	}//end for

		//loop to print out computers
		for(int i =0;i<comps.length;i++){
			System.out.println(comps[i].toString());
		}//end for

    }//end main method


}//end class