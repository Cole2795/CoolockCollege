/**
 * @(#)PremiumCustomer.java
 *
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class PremiumCustomer extends PolyCustomer {
	private int credit;

    public PremiumCustomer(String n, String a, int c) {
    	super(n,a);
    	credit = ((c>0)?c:1);

    }//end constructor

    public String toString(){
    	return super.toString() + "\nCredit: " + credit;
    }//end toString


}//end class