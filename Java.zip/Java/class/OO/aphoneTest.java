/**
 * @(#)aphoneTest.java
 *
 *
 * @author
 * @version 1.00 2016/2/4
 */


public class aphoneTest {

    public static void main (String args[]) {

	//create phone details
	App a1 = new App("App", 800, 30);
	aphone ap1 = new aphone("Iphone", "Black", a1);

	System.out.println(ap1.toString());

    }//end main method


}//end class