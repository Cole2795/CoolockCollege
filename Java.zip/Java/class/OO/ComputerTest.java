/**
 * @(#)ComputerTest.java
 *
 *
 * @author
 * @version 1.00 2016/1/14
 */
import java.io.*;
import java.util.*;
public class ComputerTest {

    public static void main(String args []) {
		Scanner kbReader = new Scanner(System.in);
		String cmake, cmodel, manuf;
		int size;

		System.out.println("Enter memory manufacturer : ");
		manuf = kbReader.nextLine();

		System.out.println("Enter computer manufacturer : ");
		cmake = kbReader.next();

		System.out.println("Enter computer model : ");
		cmodel = kbReader.next();

		System.out.println("Enter memory size : ");
		size = kbReader.nextInt();

		//String manuf = "Dell";

    	memory m1 = new memory(manuf,size);
    	Computer c1 = new Computer(cmake, cmodel, m1);

    	System.out.println(c1.toString());
    	c1.setmemorySize(120);
    	System.out.println(c1.toString());

    	System.out.println("Memory size is " + c1.getmemorySize());

    }//end class


}