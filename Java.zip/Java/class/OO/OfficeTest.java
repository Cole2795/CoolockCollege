/**
 * @(#)OfficeTest.java
 *In the OfficeTest create array of office objects, length 3.
 *printer the details of the office objects
 *
 * @author
 * @version 1.00 2016/2/5
 */


public class OfficeTest {

    public static void main(String args[]) {

	Worker workerArray[] = new worker[3];
	for(int i = 0;i<workerArray.length;i++){

		workArray[i] = new Worker()
	}

    }//end main method


}//end class