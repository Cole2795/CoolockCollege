/**
 * @(#)PloyTest.java
 *Create an array of customers and populate it with a customer, premium customer and business customer.
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class PloyTest {

    public static void main(String args[]) {

    	//create customer to object
    	PolyCustomer pc[] = new PolyCustomer[3];
    	//populate the array
    	pc[0] = new PolyCustomer("Fred", "Dublin");
    	pc[1] = new PremiumCustomer("John", "Meath", 2000);
    	pc[2] = new BusinessCustomer("Ted", "Dublin", "Jack", 123);

    	for (int i = 0;i<pc.length;i++){
    		System.out.println("\nCustomer " + (i+1));
    		System.out.println(pc[i].toString());
    	}//end for


    }//end main method


}//end class