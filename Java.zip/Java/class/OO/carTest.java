/**
 * @(#)carTest.java
 *in the carTest take all input from the user and create a car.
 *In the engine and care class use setdetails method to set the attributes and not the constructor.
 *
 * @author
 * @version 1.00 2016/1/21
 */
import java.io.*;		//need for writing to a file
import java.util.*;
public class carTest {

    public static void main(String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	String cmake, cmodel, type;
    	int size;

    	System.out.println("Enter Engine type : ");
    	type = kbReader.nextLine();

    	System.out.println("Enter car make : ");
    	cmake = kbReader.next();

    	System.out.println("Enter car model : ");
    	cmodel = kbReader.next();

    	System.out.println("Enter car size : ");
    	size = kbReader.nextInt();

    	engine e1 = new engine(type, size);
    	car c1 = new car(cmake, cmodel, e1);

    	System.out.println(c1.toString());

		//write to a file
		BufferedWriter Information = null;
		String location = "CarDetails.doc";

		try{
			Information = new BufferedWriter(new FileWriter(location, true));

		}//end try
		catch(Exception e){
			System.out.println("Cannot access file");
		}

		try{
			Information.newLine();
			Information.write(c1.toString());
			Information.close();
			System.out.println("File updated");
		}
		catch(Exception e){
			System.out.println("Cannot access file");
		}



     }//end main method


}//end class