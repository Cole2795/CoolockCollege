/**
 * @(#)teamTest.java
 *
 *
 * @author
 * @version 1.00 2015/12/11
 */
import java.io.*;
import java.util.*;
public class teamTest {

    public static void main(String args []) {
    	Scanner kbReader = new Scanner(System.in);

    	String name1, name2, league_position1, league_position2;
    	int num_goals1, num_goals2;

    	System.out.println("Please enter name  : ");
    	name1=kbReader.nextLine();
    	System.out.println("Please enter League_position  : ");

    	league_position1=kbReader.nextLine();
    	System.out.println("Please enter num_goals : ");
    	num_goals1=kbReader.nextInt();

    	//System.out.println(name1 + " "+   league_position1+ " " + num_goals1);


    	System.out.println("Please enter name  : ");
    	name2=kbReader.next();
    	System.out.println("Please enter League_position  : ");
    	kbReader.nextLine();
    	league_position2=kbReader.next();
    	System.out.println("Please enter num_goals : ");
    	num_goals2=kbReader.nextInt();

		team t1 = new team(name1, league_position1, num_goals1);
		team t2 = new team(name2, league_position2, num_goals2);

		//System.out.print(t1.getname());

		System.out.println("\nAll details of Team : ");
		System.out.println(t1.toString());
		System.out.println(t2.toString());

		t2.setname("Mr. Jones");
		t2.setleague_position("Defender");
		t2.setnum_goals(3);

		System.out.println("\nNew details for Team 2 : " );
		System.out.println("Name : " + t2.getname());
    	System.out.println("League_position : " + t2.getleague_position());
    	System.out.println("Number of goals : " + t2.getnum_goals());





    }//end main


}//end class