/**
 * @(#)team.java
 *Create a team object with attributes name, league_position and num_goals
 *Have a constructor, set and get methods and a toString method
 *take the details from the user
 *Create a team object
 *
 *Change the details using set methods
 *print the new details using get methods
 *
 * @author
 * @version 1.00 2015/12/10
 */


public class team {
	private String name, league_position;
	private int num_goals;

    public team(String name, String lp, int n) {
    	this.name = ((name.length()>0)?name:"Unknown");
    	league_position = ((lp.length()>0)?lp:"Unknown");
    	num_goals = ((n>0)?n:1);

    }//end constructor

    public void setname(String name){

		this.name = ((name.length()>0)?name:"Unknown");
    }//end setname

    public String getname(){
    	return name;

    }//end getname

    public void setleague_position(String lp){
   		 	league_position = ((lp.length()>0)?lp:"Unknown");;

    }//end setleague

    public String getleague_position(){
    	return league_position;

    }//end getleague

    public void setnum_goals(int n){
    	num_goals = ((n>0)?n:1);

    }//end setnum

    public int getnum_goals(){
    	return num_goals;

    }//end getnum
	public String toString(){
    	return "\nName : " + name + "\nLeague_position : " + league_position + "\nNum_goals : " + num_goals;

    }//end toString

}//end class