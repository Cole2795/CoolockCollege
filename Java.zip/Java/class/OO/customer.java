/**
 * @(#)customer.java
 *create a custimer object with name, id and address
 *have a toString method
 *Create a customerTest class and create a valid and invalid customer.
 *Print the details of the customer objects
 *
 * @author
 * @version 1.00 2015/12/4
 */


public class customer {
	private   String name,address;
	private int id;

	//constructor
    public customer(String name, String a, int i) {
    	this.name = name;
    	address = ((a.length()>0)?a:"Unknown");
    	id = ((i>0)?i:111);

    }//end constructor

    //setName method
    public void setname(String name){
    	this.name = name;
    }

    //getname method returns the name to Test class
    public String getname(){
    	return name;
    }

	//set id takes an id and sets the id instance variable
	public void setid(int i){
		id = ((i>0)?i:111);
	}

	public int getid(){
		return id;
	}

	public void setaddress(String a){
		address = ((a.length()>0)?a:"Unknown");
	}

	public String getaddress(){
		return address;
	}

    public String toString(){
    	return "\n\nCustomer Details\nName : " + getname() + "\nAddress : " + address + "\nID : "+ id ;
    }


}