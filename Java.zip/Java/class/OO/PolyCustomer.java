/**
 * @(#)PolyCustomer.java
 *Create a customer object with name and address
 *Create a premium customer which inherits from customer but also has credit limit
 *Have a business customer that inherits from customer but also had id & personal assistant(String PAname)
 *
 *Create an array of customers and populate it with a customer, premium customer and business customer.
 *
 * @author
 * @version 1.00 2016/2/25
 */


public class PolyCustomer {
	private String name, address;

    public PolyCustomer(String n, String a) {

    	name = n;
    	address = a;
    }

    public String toString(){
    	return "\nName: " + name + "\naddress: " + address;
    }//end toString


}//end class