/**
 * @(#)memory.java
 *
 *
 * @author
 * @version 1.00 2016/1/14
 */


public class memory {

	private String manufacture;
	private int size;

    public memory(String m, int s) {

    	this.manufacture = m;
    	size = ((s>0)?s:0);

    }//end memory

    //setsize method
    public void setmemorysize(int s){
    	size = ((s>0)?s:0);
    }

    public int getmemorysize(){
    	return size;
    }

    public String toString(){

    	return "\nMemory details\nManufacture : " + manufacture + "\nSize : " + size;

    }//end toString


}//end class