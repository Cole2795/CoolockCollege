/**
 * @(#)customerTest.java
 *
 *
 * @author
 * @version 1.00 2015/12/4
 */


public class customerTest {

    public static void main (String args[]) {

    	customer c1 = new customer("Nicole", "Dublin",123);
    	customer c2 = new customer("Fred","", -123);

    	//print customer details
    	System.out.println(c1);
    	System.out.println(c2.toString());

    	//change c1 name
    	c1.setname("Nicole Campbell");
    	c1.setid(456);
    	c1.setaddress("Dublin City");

    	//change attribute values
    	System.out.println("Name after change is " +c1.getname() );
    	System.out.println("Address after change is " +c1.getaddress() );
    	System.out.println("ID after change is " +c1.getid() );

    }//end main method


}//end class