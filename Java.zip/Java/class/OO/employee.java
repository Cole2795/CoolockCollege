/**
 * @(#)employee.java
 *create an employee object with name, id and numhours (number of hours)
 *Have a constructor
 *Have set and get method for each instance variable (attribute)
 *have a toString method
 *
 *In the employeeTest class create a valid and invalid employee and change details of the
 *invalid employee using set methods and display the new details using the get methods
 *
 *Take the employess details in from the user
 *have a caluate wages method that will have rate passed to it and will calculate and return the wage
 * @author
 * @version 1.00 2015/12/10
 */


public class employee {
	private String name;
	private int id, numhours;

	//constructor
    public employee(String name, int i, int n) {
    	//this.name = name;
    	this.name = ((name.length()>0)?name:"Unknown");
    	id = ((i>0)?i:111);
    	numhours = ((n>0)?n:1);

    }//end constrctor

    public void setname(String name){
    	//this.name = name;
		this.name = ((name.length()>0)?name:"Unknown");
    }//end setname

    public String getname(){
    	return name;

    }//end getname

    public void setid(int i){
    	id =((i>0)?i:1);

    }//end setid

    public int getid(){
    	return id;

    }//end detid

    public void setnumhours(int n){
    		numhours = ((n>0)?n:000);

    }//end setnumhours

    public int getnumhours(){
    	return numhours;

    }//end getnumhours

	public double calculateWages(double rate){
		int hoursovertime;
		if(numhours>39){
			hoursovertime = numhours - 39;
			return rate * numhours + (hoursovertime * 1.5);
		}// end if
		else{
				return rate * numhours;
		}//emd if


	}//end calculateWages


    public String toString(){
    	return "\nName : " + name + "\nID : " + id + "\nNumhours : " + numhours;

    }//end toString

}//end class