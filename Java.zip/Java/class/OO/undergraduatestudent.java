/**
 * @(#)undergraduatestudent.java
 *Create an undergraduate-student which is a student but also have course name and course length.
 *
 * @author
 * @version 1.00 2016/3/3
 */


public class undergraduatestudent extends students {

    private String coursename;
	private int courselength;

    public undergraduatestudent(String na, int i, phone2 p1, String cn, int cl) {
    	super(na, i, p1);
    	coursename = cn;
    	courselength = cl;
    }//end constructor

    public String toString(){
    	return super.toString() + "\nCourse Name: " + coursename + "\nCourse Length: " + courselength;
    }//end toString


}//end class