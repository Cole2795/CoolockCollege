/**
 * @(#)wateranimal.java
 *
 *
 * @author
 * @version 1.00 2016/2/26
 */


public class wateranimal extends animal {

	private int size, speed;

    public wateranimal(String name, String c, int sz, int so) {
    	super(name, c);
    	this.size = ((sz>0)?sz:5);
    	this.speed = so;
    }//end constructor

    public String toString(){
    	return super.toString() + "\nSize: " + size + "\nSpeed: " + speed;
    }//end toString

}//end class