/**
 * @(#)Q2BandC.java
 *
 *
 * @author
 * @version 1.00 2015/9/23
 */

import java.io.*;
import java.util.*;
public class Q2BandC {

    public static void main (String args []) {

    	//Q2b
    	Scanner kbReader = new Scanner(System.in);
       	String name;
    	int age;
    	//prompt user for their name
    	//take in their name
    	System.out.println("Please enter your name");
    	name = kbReader.nextLine();
    	//prompt user for their age
    	//take in their age
    	System.out.println("Please enter your age");
    	age = kbReader.nextInt();
    	//use loop to print Age amount of stars
    	for(int i=1; i<=age; i++){
    		System.out.println("*");
    	}

    	//Q2c
    	for (int i = 2; i<=20; i+=2){
    		System.out.println(i);
    	}
    }


}