/**
 * @(#)gradescheck.java
 *take 5 grades from the user. User a method to check non-digits
 *send the grade to a method that will count the number of passes and fails.
 *store the grades in an array and display all grades after the number of passes/fails.
 *
 * @author
 * @version 1.00 2015/10/15
 */
import java.io.*;
import java.util.*;
public class gradescheck {

	static Scanner kbReader = new Scanner(System.in);
	static int pass =0, fail = 0;
    public static void main (String args []) {

    	String strgrade;
    	int grades[] = new int[5];
    	int results=0;


    	for(int i = 0; i<grades.length; i++){
    		System.out.println("Enter grade " + (i+1) + " : ");
    		strgrade = kbReader.next();
			//pass strgrade to the method digitcheck and results will hold the value returned by the method
    		results = digitcheck(strgrade,i);
    		//put results into the array
			grades[i] = result;
			//pass results to passfails method
    		passfails(grades[i]);
    	}//end for

	   	System.out.println("The number were passes " + pass);
    	System.out.println("The number were fails " + fail);

    	//loop to print out grades
    	for(int i =0; i<grades.length; i++){
    		System.out.println("Grades " + (i+1) + " : ");
    	}

    }// end main method

    public static int digitcheck(String mstrgrade, int mi){
    	while(!mstrgrade.matches("//d+")){
    		System.out.println("Error, only numbers");
    		System.out.println("Enter grade " + mi + " : ");
    		mstrgrade = kbReader.next();
    	}//end while

    	int num;
    	num = Integer.parseInt(mstrgrade);
    	return num;

    }//end grades

    public static void passfails(int m_strgrade){
    	if(m_strgrade>50){
    		pass++;

    	}
    	else{
    		fail++;
    	}

    }//end passfail

}