/**
 * @(#)gradescheckMethod.java
 *take in 5 grades
 *use a method to check for non-digits. the method will return an int
 *get the average grade
 *
 * @author
 * @version 1.00 2015/10/9
 */
import java.io.*;
import java.util.*;
public class gradescheckMethod {
	 static Scanner kbReader = new Scanner(System.in); //declared globally (accessible by all method in

    public static void main (String args []) {

    	String strgrade;
    	int grade, total=0, average;
    	for(int i =1; i<6; i++){
    		System.out.println("Please enter grade " + i + " : ");
    		strgrade = kbReader.next();
			//pass strgrade to a method to check for non digits and pass i
    		grade = digitcheck(strgrade,i);

    		//add grade to total
    		total += grade;
    	}//end for
    	 //get average grade
    	 average = total/5;

    	 System.out.println("Average is " + average);

    }//end method

    public static int digitcheck(String mstrgrade, int mi){

    	while(!mstrgrade.matches("\\d+")){
    		System.out.println("Error, only number");
    		System.out.println("Enter grade " + mi + " : ");
    		mstrgrade = kbReader.next();

    	}//end while
		int num;
		num = Integer.parseInt(mstrgrade);
		return num;

    }//end digitcheck


}//end class