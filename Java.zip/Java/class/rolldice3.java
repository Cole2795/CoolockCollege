/**
 * @(#)rolldice3.java
 *take two numbers from the user
 *first number is how many times we want to generate a random number
 *second number is the number we want to generate up to e.g. 1 to XX
 *Pass the two of the number to a method and display the numbers generated
 *
 * @author
 * @version 1.00 2015/10/2
 */
import java.io.*;
import java.util.*;
public class rolldice3 {

    public static void main (String args []) {

    	Scanner kbReader = new Scanner (System.in);
    	int numtimes, Urange;

    	System.out.println("Enter the number of times to generate the random number : ");
    	numtimes = kbReader.nextInt();

    	System.out.println("Enter the max number to generate : ");
    	Urange = kbReader.nextInt();

    	//method call
    	generate(numtimes, Urange);
    }//end method

    public static void generate(int m_numtimes,int m_Urange){
  		//loop to generate the random numbers
  		for(int i = 1; i<= m_numtimes; i++){
  			//generate the number
  			System.out.println(1+(int)(Math.random()* m_Urange));
  		}//end for
    }//end generate method


}//end class