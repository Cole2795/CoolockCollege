/**
 * @(#)Q3ii.java
 *
 *
 * @author
 * @version 1.00 2015/9/23
 */

import java.io.*;
import java.util.*;
public class Q3ii {

	//main method
    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	int numb = 10;
    	int grade [] = new int[numb]; //delcare array to hold grades
    	int total=0, average;
    	//loop to take in grades from the user
    	for(int i =0; i<grade.length; i++){

    		System.out.println("enter grade: " + (i+1) + " : ");
    		grade[i] = kbReader.nextInt();

			//add grade to total
			total += grade[i];

    	}//end for loop

		average = total/grade.length;

		System.out.println("Grades above the average are : \n" );

		for(int i =0;i<grade.length; i++){
			if (grade[i] > average){
				System.out.println(grade[i]);
			}//end if
		}//end for



    }//end main method


}