/**
 * @(#)Q1.java
 *Nicole Campbell
 *
 * @author
 * @version 1.00 2015/9/17
 */
import java.util.Scanner;

public class Q1 {

	//main method
    public static void main (String args []) {

    Scanner kbReader = new Scanner(System.in);
    int age, highest, lowest = 200;

    int i =1;
    while(i<5)
    {
    	System.out.println("Please enter you age " + i + " : ");
    	age = kbReader.nextInt();

    	if(age >highest)
    	{
    	  	highest = age;
    	}
    	if(age < lowest)
    	{
    		lowest = age;
    	}
		i++;
    }//end while loop
    System.out.println();

    System.out.println("Highest age is\t " + highest + "\nLowest age is\t " + lowest);


    System.out.println();
    }//end main method


}//end class