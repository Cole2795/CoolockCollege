/**
 * @(#)gradeMethod.java
 *write program to take a percentage grade from the user.
 *Pass this to a method and return "Distinction", "Merit", "Pass" or "Unsuccessful
 *Tell the user their grade
 * @author
 * @version 1.00 2015/10/22
 */
import java.io.*;
import java.util.*;
public class gradeMethod {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	int grade;
    	String result;
    	System.out.println("Please enter grade : ");
    	grade = kbReader.nextInt();

    	result = getgrade(grade);

    	System.out.println("The grade is " + result);
    }//end main method

    public static String getgrade(int x){

    	if(x>79){
    		//System.out.println("Distinction");
    		return "Distinction";
      	}
    	else if(x>65){
    		//System.out.println("Merit");
    		return "Merit";
    	}
    	else if(x>49){
    		//System.out.println("Pass");
    		return "Pass";
    	}
    	else{
    		//System.out.println("Unsuccessful");
    		return "Unsuccessful";
    	}
    	 //return result;
    }//end result


}//end class