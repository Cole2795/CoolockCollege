/**
 * @(#)whileRollmethod.java
 *call a method that will roll a dice until 6 is rolled.
 *return the number of times the dice had to be rolled before six appeared
 *
 * @author
 * @version 1.00 2015/10/9
 */
import java.io.*;
import java.util.*;
public class whileRollmethod {

    public static void main (String args []) { //main method
       	Scanner kbReader = new Scanner(System.in);
    	//declare variables
    	int numtimes;
    	//method call
    	numtimes = roll();

    	System.out.println("Dice rolled " + numtimes + " times before getting a 6");
    }//end method

    public static int roll(){
    	int counter =0, dice=0;

    	while(dice !=6){
    		//roll dice
    		dice = 1+(int)(Math.random()*6);
    		//print the value of dice
    		//System.out.println(dice);
    		//increment counter
    		counter++;
    		//have a 1 second delay before showing each roll
    		try{
    			Thread.currentThread().sleep(1000);
    			//print the value of dice
    			System.out.println(dice);
    		}//end try
    		catch(Exception e){
    			System.out.println("Could not access current thread");
    		}//end catch
    	}//end while

    	return counter;
    }

}//end class