/**
 * @(#)numbersquared.java
 *take number from the user. Pass it to a method and return the square of number
 *
 * @author
 * @version 1.00 2015/10/22
 */
import java.io.*;
import java.util.*;
public class numbersquared {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);

    	//take number from the user
    	int number;
    	int result;
    	System.out.println("Please enter number : ");
    	number = kbReader.nextInt();

    	result = square(number);
		System.out.println("The square of number is " + result);
    }//end main method

    public static int square(int mnumber){
    	return (mnumber * mnumber);
    }//end square


}