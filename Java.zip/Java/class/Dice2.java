import java.io.*;
import java.util.*;
public class Dice2{

	public static void main (String args []){
		Scanner kbReader = new Scanner(System.in);
		int numb, result;
		System.out.println("Enter the number of times to generate the random number : ");
		numb = kbReader.nextInt();

		result = generate(numb);
		System.out.println("The number of times to generate the random number " + result);
	}	
	
	public static int generate(int mnumb){
		for(int i = 0; i<=5; i++){
			return (1+(int)(Math.random()* mnumb));
		
		//return result;
		}
	}

}//end class