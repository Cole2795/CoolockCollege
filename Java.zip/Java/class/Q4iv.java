/**
 * @(#)Q4iv.java
 *Write program to take 5 names and age from the user.
 *print the name who are above the average age. Check for non digits
 *
 * @author
 * @version 1.00 2015/9/24
 */
import java.io.*;
import java.util.*;
public class Q4iv {

    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);

    	String names[] = new String[5];
    	int ages[]= new int[5], total = 0, average;
    	String strage;

    	//loop to take 5 name and ages
    	for(int i =0;i<ages.length;i++){
    		System.out.println("Enter name " + (i+1) + " : ");
    		names[i] = kbReader.nextLine();
    		System.out.println("Enter age for " + names[i] + " : ");
    		//take in age as a string
    		strage = kbReader.nextLine();

    		//check strage only contains digits
    		while(!strage.matches("\\d+")){
    			System.out.println("Error, numbers only");
    			System.out.println("Enter age for " + names[i] + " : ");
    			//take in age as string
    			strage = kbReader.nextLine();
    		}//end while

    		//change strage to an int and store it in array
    		ages[i] = Integer.parseInt(strage);

    		//add the age to the total
    		total += ages[i];
    	}//end for

    	//average
    	average =total/ages.length;

		System.out.println("\nPeople above or equal average age are :\n");
    	//loop to print names who are older than the average
    	for(int i =0;i<ages.length;i++){
    		if(ages[i] > average){
    			System.out.println(names[i]);
    		}//end if
    	}//end for


    }//end main method


}//end class