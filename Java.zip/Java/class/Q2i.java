/**
 * @(#)Q2i.java
 *
 *
 * @author
 * @version 1.00 2015/9/23
 */

import java.io.*;
import java.util.*;
public class Q2i {

    public static void main(String argse []) {

    	Scanner kbReader = new Scanner(System.in);
    	String password;
    	//String pass ="pin";
    	//prompt the user for the password
    	System.out.println("Please enter your password");
    	password = kbReader.nextLine();

    	//change password to lowercase
    	password = password.toLowerCase();

    	//check if the password is not correct
    	while(!password.matches("pin")){
    		//give the user an error message
    		System.out.println("Incorrect password");
    		//beep
    		System.out.println("\007");
    		//prompt the user for the password
    		System.out.println("Enter your password");
    		password =kbReader.nextLine();


    		//change password to lowercase
    		password = password.toLowerCase();

    	}//end while
		//print hello
    	System.out.println("Hello, Welcome to our system.");
    	}//end main method
    }//end class


