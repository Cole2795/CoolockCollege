/**
 * @(#)shapesMethods.java
 *have a menu which will ask the user what shape they want printed
 *the menu should keep looping until they choose to exit
 *the menu is
 *1: Square
 *2: Rectangle
 *3: Traingle
 *4: Quit
 *each menu option will take inputs (length for square and width for rectangle)
 *from the user and pass the inputs to the method
 *Exit will also have a method
 *
 * @author
 * @version 1.00 2015/10/16
 */
import java.io.*;
import java.util.*;
public class shapesMethods {
	//Static Scanner kbReader = new Scanner (System.in);
    public static void main (String args []) {
		Scanner kbReader = new Scanner(System.in);
 		String square, rectangle, triangle, quit;
 		int length = 0, choice =0, width = 0;
		choice = kbReader.nextInt();
 		while(choice !=4){
 			System.out.println("Please choose the option");
 			System.out.println("1. Square");
 			System.out.println("2. Rectangle");
 			System.out.println("3. Triangle");
 			System.out.println("4. Quit");

 			if (choice == 1){
 				System.out.println("Square");
 				System.out.println("Enter length of square:");
 				length = kbReader.nextInt();
 				drawsquare(length);
 			}
 			if (choice == 2){
 				System.out.println("Rectangle");
 				System.out.println("Enter length of rectangle:");
 				length = kbReader.nextInt();
 				System.out.println("Enter width of rectangle:");
 				width = kbReader.nextInt();
 				drawrectangle(length,width);
 			}
 			if (choice ==3){
 				System.out.println("Triangle");
 				System.out.println("Enter the length of triangle:");
 				length = kbReader.nextLine();
 				drawtriangle();
 			}
 			if (choice == 4){
 				exit();
 			}

  		}//end while

    }//end main method

 	public static void drawsquare(int mlength){
 		for(int i = 1; i<=mlength; i++){
 			for(int x = 1; x<=length; i++){
 				System.out.println("*");
 			}//end inner for loop
 			System.out.println();
 		}//end outer for loop

 	}//end drawsquare

 	public static void drawrectangle(int mlength, int mwidth){
 		for(int i = 1; i<=mlength; i++){
 			for(int x = 1; x<=mwidth; i++){
 				System.out.println("*");
 			}//end inner for loop
 		}//end outer for loop
 	}//end drawrectangle

 	public static void drawtriangle(int mlength){
 			for(int i = 1; i<=mlength; i++){
 				for(int x = 1; i<=i; i++){
 					System.out.println("*");
 				}//end inner for loop
 			}//end outer for loop
 	}//end drawtriangle





}