import java.io.*;
import java.util.*;
public class TwoNames2 {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	String name1, name2;
    	int age1, age2;
    	String result;

    	System.out.println("please enter your name1 :");
    	name1 = kbReader.nextLine();
    	System.out.println("please enter your age1 :");
    	age1 = kbReader.nextInt();
    	System.out.println("Please enter name 2 : ");
    	name2 = kbReader.next();
    	System.out.println("please enter your age2 :");
    	age2 = kbReader.nextInt();

    	result = twonames(name1, age1, name2, age2);
    	System.out.println("Oldest is "+ result);
    }//end main method

	public static String twonames(String mname1, int mage1, String mname2, int mage2){
		if(mage1>mage2){
			return mname1;
		}
		else if(mage1<mage2){
			return mname2;
		}
		else{
			return "Both";
		}


	}//end Names method

}//end class