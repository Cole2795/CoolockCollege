/**
 * @(#)ArraySub.java
 *declare arrays to hold name, addresses and ages
 *ask the user what person they want to view (id 1-5)
 *pass the id to a method that will print all the details held for that users id
 *
 * @author
 * @version 1.00 2015/10/15
 */
import java.io.*;
import java.util.*;
public class ArraySub {

 	static int ages [] = {21,32,43,54,23};
 	static String names[] = {"Ted", "Fred", "Will", "Bill", "Bob"};
 	static String address[] = {"Dublin", "Meath", "Louth", "Cork", "Galway"};

	//static String courses [] = {"Computer Science", "Art", "Business Studies", "Childcare", "Nursing"};
	
    public static void main (String args []) {
    	 Scanner kbReader = new Scanner(System.in);
    	 int id;
    	 int found = 0, position = 0;
    	 System.out.println("Please enter your ID of the person :");
    	 String names = kbReader.nextLine();
    	    	 
    	 System.out.println("Enter id numbers :");
    	 id = kbReader.nextInt();

    	 System.out.println("Please enter you address for " + names + " : ");
    	 String address = kbReader.next();

    	 System.out.println("Please enter your age " + names + " : ");
    	 int ages = kbReader.nextInt();
    	 
    	 System.out.println("Please enter your course:");
    	 String courses = kbReader.next();
    	 
    	 persondetail(names,id,address,ages,courses);
    }//end main method

	public static void persondetail(String mnames, int mid, String maddress, int mages, String mcourses){
		System.out.println("Person Applications Details");
		System.out.println("Name : " + mnames);
		System.out.println("id : " + mid);
		System.out.println("Address : " + maddress);
		System.out.println("Age : " + mages);
		System.out.println("Course :" + mcourses);
	}//end persondetail

}