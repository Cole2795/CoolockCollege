/**
 * @(#)OOPAssignment.java
 *
 *
 * @author
 * @version 1.00 2015/11/5
 */
import java.io.*;
import java.util.*;
public class OOPAssignment {
	static String name[]= {"Keith", "Paul", "Sarah"};
	Static int pin[]= {1234, 4567, 5678};
	Static int balance[]= {400, 200, 100};
	Static int overdraft[]= {1, 0, 0};
    public static void main(String args[]) {
	
	login();

    }end main method
 
    public static void login(){
	int found =0, positon =0;
	System.out.println("Welcome to Bank System");
	System.out.println("Please choose an option");
	System.out.println("1. Login");
	System.out.println("2. Quit");
	int ch = kbReader.nextInt();
	switch(ch){
		case 1:
			System.out.println("Please enter your pin");
			pin = kbReader.nextInt();
			for(int i =0; i<pin.length; i++){
				if(pin ==pin[i]){
					found = 1;
					positon = i;
				}//end if
			}//end loop
		case 2:
			if(found == 0){
				System.out.println("Thank you for using the Bank System");
				System.exit(0);
			}//end if
	}//end switch case
    }end login
	

}//end class