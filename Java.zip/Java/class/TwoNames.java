/**
 * @(#)TwoNames.java
 *take two names from the user
 *
 *pass these name to a method.
 *The method will return the name of the person with the longest name or the word
 *"both" if they both have the same name.length.
 *print the longest name
 * @author
 * @version 1.00 2015/10/9
 */
import java.io.*;
import java.util.*;
public class TwoNames {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	String name1, name2;
    	String result;

    	System.out.println("please enter your name1 :");
    	name1 = kbReader.nextLine();
    	System.out.println("Please enter name 2 : ");
    	name2 = kbReader.nextLine();

    	result = twonames(name1, name2);
    	System.out.println(result + " has the longest name");
    }//end main method

	public static String twonames(String mname1, String mname2){
		if(mname1.length()>mname2.length()){
			return mname1;
		}//end if
		else if(mname1.length()<mname2.length()){
			return mname2;
		}//end if
		else{
			return "both";
		}//end if

	}//end Names method

}