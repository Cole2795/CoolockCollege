import java.io.*;
import java.util.*;
public class Grade4{
		static Scanner kbReader = new Scanner(System.in);
	public static void main (String args []){
		//Scanner kbReader = new Scanner(System.in);
		String strgrade;
		int grade, result=0;
		System.out.println("Please enter your grade : ");
		strgrade = kbReader.next();

		result = check(strgrade);
		if(result>49){
			System.out.println("Pass");
		}
		else{
			System.out.println("Fail");
		}
	}
	public static int check(int mstrgrade){
		while(!mstrgrade.matches("\\d+")){
			System.out.println("Error, only number");
			System.out.println("Enter grade : ");
			mstrgrade = kbReader.next();
		}
		//int num;
		return Integer.parseInt(mstrgrade);

	}

}//end class