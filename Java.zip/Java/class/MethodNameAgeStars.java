/**
 * @(#)MethodNameAgeStars.java
 *Take a name and age from the user
 *pass these to a method
 *The method should print the name and print age number of stars
 *
 * @author
 * @version 1.00 2015/10/2
 */
import java.io.*;
import java.util.*;
public class MethodNameAgeStars {

    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	String name;
    	int age;
    	System.out.println("Please enter name : ");
    	name = kbReader.nextLine();
    	System.out.println("Please enter age : ");
    	age = kbReader.nextInt();

    	Stars(name,age);
    }

    public static void Stars(String mname, int mage){
    	System.out.println("Hello " + mname);

		String spaces = "";
    	for(int i =0; i<=mage; i++){
    		System.out.print(spaces);
    		System.out.println("*");
    		spaces +=" "; //add (or append) a space to the String spaces
    	}//end for
    }//end Stars method

}//end class