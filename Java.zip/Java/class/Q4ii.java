/**
 * @(#)Q4ii.java
 *Write a program which takes in the age of people.
 *the loop will be be stopped by a sentinel. Print the average age to the screen
 *
 * @author
 * @version 1.00 2015/9/24
 */
import java.io.*;
import java.util.*;
public class Q4ii {
	//main method
    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	int age, total=0, average, counter=0;

    	//take in the age
    	System.out.println("Enter, -1 to quit : ");
    	age = kbReader.nextInt();

    	//loop to take in the ages
    	while(age!= -1){
    		//add the age to the total
    		total += age;
    		//increment counter
    		counter++; //counter = counter +1;

    		//take in the age
    		System.out.println("Enter, -1 to quit : ");
    		age = kbReader.nextInt();

    	}//end while

    	if (counter !=0){
    		//get average
    		average = total/counter;

    	  	System.out.println("Average age is : " + average);
    	}
    	else{
    		System.out.println("No grades entered");
    	}//end if


		//q3iii
		//write a program that delcare an integer array of length 5.
		//then the program prints the sum of the values in the array.
		int numbers [] = {10,39,47,32,7};
		int total2 = 0;

		for(int i =0;i<numbers.length; i++){
			total2+=numbers[i];
		}//end for

		System.out.println("\n\nQuestion 3, total of the numbers in the array is " + total);
    }//end main method


}//end class