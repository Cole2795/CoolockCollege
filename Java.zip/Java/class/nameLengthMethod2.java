/**
 * @(#)nameLengthMethod2.java
 *pass your name to a method and have the method return the length of your name
 *tell the user if they have a long or short name
 *
 * @author
 * @version 1.00 2015/10/8
 */
import java.io.*;
import java.util.*;
public class nameLengthMethod2 {

    public static void main (String args[]) {
    	Scanner kbReader = new Scanner(System.in);

    	int result; // this will hold the number return by the method

    	//method call
    	result = namelength("Nicole");

    	if(result> 10){
    		System.out.println("Your name is long");
       	}
       	else{
       		System.out.println("Your name is short");
       	}
    }//end main method

    public static int namelength(String x){
    	int num;
    	num = x.length(); //assign the length of your name to num
    	return num; //retrun num
    }//end namelength

}