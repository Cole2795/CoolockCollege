/**
 * @(#)ifExample.java
 *
 *
 * @author
 * @version 1.00 2015/9/23
 */

import java.io.*;
import java.util.*;
import java.util.Date;
public class ifExample {
	//main method
    public static void main (String args []) {

		//create a new Date object
		Date d = new Date();

    	int age = 20;

		System.out.println(d);

    	if (age >17)
    		System.out.println("Congratualtions");
    		System.out.println("You can vote");

    }//end main method


}//end class