/**
 * @(#)agearray.java
 *declare an array globally and pass down a subscript value to a method
 *double the age in the method
 *print out the ages
 *
 * @author
 * @version 1.00 2015/11/5
 */
import java.io.*;
import java.util.*;
public class agearray {

	static int ages [] = {21, 32, 34, 19, 43};

    public static void main(String args[]) {

    	Scanner kbReader = new Scanner(System.in);

    	//pass the middle array value to the method
    	doubleage(2);
    	System.out.println("After the method the new age is " + ages[2]);

    }//end main method

    public static void doubleage(int msub){
    	ages[msub] = ages[msub] *2;

   }//end doubleage

}//end class