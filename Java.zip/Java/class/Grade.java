/**
 * @(#)Grade.java
 *Nicole Campbell
 *
 * @author
 * @version 1.00 2015/9/17
 */
import java.io.*;
import java.util.*;

public class Grade {

	//main method
    public static void main (String args []) {

    	Scanner kbReader = new Scanner(System.in);
    	int grade, pass=0, fail=0;


    	for(int i=0; i<10; i++)
    	{
    		System.out.println("Please enter grade " + (i+1) + " : ");
    		grade = kbReader.nextInt();

    		if (grade>49)
    		{
    			pass++;
    		}
    		else
    		{
    			fail++;
    		}
    	}//end for
		//print a blank line
		System.out.println();

    	//show the user the number of passes and fails
    	System.out.println("The number of passes were : " + pass);
    	System.out.println("The number of fails were : " + fail);

    	//print a blank line
		System.out.println();
    }//end main method


}//end class