/**
 * @(#)person.java
 *NameAgecheck
 *
 * @author
 * @version 1.00 2015/10/6
 */
import java.io.*;
import java.util.*;
public class person {

    public static void main (String args []) {
    	Scanner kbReader = new Scanner(System.in);
    	String names [] = new String[5];

   		int grades [] = new int[5];
    	int high = 0, low = 100;
    	String highname ="" , lowname =""; //need to take in the grades as a String and Validate it

	    //loop to take in the name and grades
    	for(int i = 0; i<grades.length; i++){
    	System.out.println("Enter name : ");
    	names[i] = kbReader.next();
    	//prompt for grade
    	System.out.println("Enter grade for " + names[i] + " :");
    	grades[i] = kbReader.nextInt();

		if(grades[i] > high){
			high = grades[i];
			highname = names[i];
		}

		if(grades[i] < low){
			low = grades[i];
			lowname = names[i]; //hold onto the name of the person with the lowest grade(store it in lowname)
		}
    }
    System.out.println("Results after loop 1 : ");
    System.out.println("High grade " + high + " by " + highname);
    System.out.println("Low grade " + low + "by " + lowname);

        highname = "person with highgrade:\n";
    	lowname = "person with lowgrade:\n";
    	System.out.println("\n\nResults after loop 2\n");

    	//loop to get all with high and low grade
    	for(int i =0; i<grades.length; i++){
    	//check it the grade is the highest grade
    		if(grades[i]== high){
    			highname += names[i] + "\n";
    		}

    		if(grades[i] == low){
    			lowname += names[i] + "\n";
    		}
    }
    //show all names with highest and lowest grade
    System.out.println(highname + "\n\n" + lowname);



  }

}
