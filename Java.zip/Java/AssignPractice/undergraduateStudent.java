/**
 * @(#)undergraduateStudent.java
 *
 *
 * @author
 * @version 1.00 2016/3/10
 */

package practice;
public class undergraduateStudent extends student {
	private String courseName;
	private int courseLength;

    public undergraduateStudent(String name, int id, phone p1, String courseName, int courseLength) {
    	super(name, id, p1);
    	this.courseLength = courseLength;
    	this.courseName = courseName;
    }

	public void setcourseLength(int courseLength){
		this.courseLength = courseLength;
	}

	public void setcourseName(String courseName){
		this.courseName = courseName;
	}

	public String toString(){
		return super.toString() + "\nCourse Name : " + courseName + "\nCourse Length : " + courseLength;
	}


}