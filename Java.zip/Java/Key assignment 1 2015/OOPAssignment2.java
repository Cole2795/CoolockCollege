/**
 * @(#)OOPAssignment.java
 *
 *
 * @author
 * @version 1.00 2015/11/5
 */
import java.io.*;
import java.util.*;
public class OOPAssignment2 {
	static Scanner kbReader = new Scanner(System.in);
	static String name[]= {"Keith", "Paul", "Sarah"};
	static int pin[]= {1234, 4567, 5678};
	static int balance[]= {400, 200, 100};
	static int overdraft[]= {1, 0, 0};
	static int position=0;
	static int choice = 0;
	static boolean flag = false;
	static int newpin, pins;
	static int checklodge, checkwithdraw, clogin, valid, balances, amount, option, check, pincheck, ch;
	static String stramount, strpin, validate, strcheck, validation, strchoice, valids, choices, chi;

	public static void main(String args[]) {
		//method class
		login();

    }//end main method
    ////////////////////login//////////////////////////
    public static void login(){

		int found =0;

		System.out.println("\n\nWelcome to Bank System");//print out on command prompt say Welcome to Bank System
		System.out.println("Please choose an option");//choose an option login or quit
		System.out.println("1. Login");//login enter pin
		System.out.println("2. Quit");//quit to finish Thank you using for using the Bank System
		String chi = kbReader.next();//pick a choice from 1 to 2 as a string
		ch = validateoption(chi);//validate option

		switch(ch){//switch statement
			case 1:


				System.out.println("Please enter your pin");
				String strpin = kbReader.next();
				pincheck = validatepins(strpin);	//validate pin

				for(int i =0; i<pin.length; i++){
					if(pincheck ==pin[i]){
						found = 1;
						position = i;	//hold onto the position of the record in the array
						//break;
						//call the menu and send the position to the menu as an argument
						menu(position);

					}//end if

				}//end for loop
					if(found == 0){
						System.out.println("Wrong details");//wrong pin printout wrong details
						login();//if pin wrong will go back to login method
					}//end if


			case 2:

				System.out.println("Thank you for using the Bank System");//finish system
				System.exit(0);



			}//end switch case

    	}//end login

	//////////////validateoption//////////////////
	public static int validateoption(String mchi){
		while(!mchi.matches("[1-2]")){
			System.out.println("Error only number\n Enter option from 1-2 \n1.login\n2.Quit");
			mchi = kbReader.next();
		}//end while
		return Integer.parseInt(mchi);
	}//end validateoption

	//////////////validate pin login///////////////////////
    public static int validatepins(String m){
    	while(!m.matches("\\d+")){
    		System.out.println("Error, it only four digits\nPlease enter pin ");//enter pin only number not letters
    		m = kbReader.next();

      	}//end while
		return Integer.parseInt(m);

    }//end pins

	//////////////////menu/////////////////
    public static void menu(int mposition){

		choice = 0;
		while(choice != 4){
				System.out.println("\nWelcome " + name[mposition] + "\nYou have " + balance[mposition] + "\nOverdraft facility : " + overdraft[mposition]);
				System.out.println("\n");
				System.out.println("1. Lodge");
				System.out.println("2. Withdraw");
				System.out.println("3. Change pin");
				System.out.println("4. Quit");
				//take the users choice 1-4
				System.out.println("Enter choice : ");
				String choices = kbReader.next();	//validate choice
				choice = validatechoice(choices);
				if(choice == 1){//choice 1 is balance
					//new balance to add up
					System.out.println("\n");
					System.out.println(name[position] + "\nYou have " + balance[position]);
					System.out.println("Enter amount to lodge : ");
					String stramount = kbReader.next();
					amount = validate(stramount); //validate balances
					balance[position] = lodge(amount);		//THE BALANCE ARRAY NEEDS TO BE UPDATED
					System.out.println("\n------------- New Balance is " + balance[position] + " ---------------");

				}//end if
				else if(choice ==2){//choice 2 is withdraw
					//new balacne to take away
					System.out.println("\n");
					System.out.println(name[position] + "\nYou have " + balance[position]);
					System.out.println("Enter amount :  ");
					String stramount = kbReader.next();
					amount = validates(stramount); //valdiate withdraw
					balance[position] = withdraw(amount);	//THE BALANCE ARRAY NEEDS TO BE UPDATED
					System.out.println("\n----------------- New Balance is " + balance[position] + " --------------");

				}//end if 2
				else if(choice ==3){//choice 3 is changepin
					//pin want same pin or change pin
					boolean flag = false;
					String strnewpin;
					System.out.println("Please your pin");
					strnewpin = kbReader.next();		//validate newpin
					newpin = pincheck(strnewpin);
					pin[position] = changepin(newpin); /////////////////////THE NEW PIN SHOULD BE PASSED BACK TO THE METHOD CALL
					System.out.println("\n-----------------Your pin number is " + newpin + " ----------------------"); //////UPDATE THE PIN ARRAY WITH THE NEWPIN
			}//end if 3
			else if(choice == 4){//choice 4 is Quit
				//finish bank system go back to login
				System.out.println("Thank you  for using the Bank System");
				System.out.println("\n");
				exit();

			}//end if 4
			else{
				//only 1 to 4
				System.out.println("No number from menu, Only 1 to 4");//only have 1-4

			}
		}//end while

  }//end menu

  //////////////validatechoice///////////////
  public static int validatechoice(String c){
  		while(!c.matches("\\d+")){
  			System.out.println("Error only number,\n Enter choice 1-4 : ");
  			c = kbReader.next();
  		}//end while
  		return Integer.parseInt(c);
  }//end validatechoice

	/////////////////validate choice//////////////////
  public static int valids(String z){
	while(!z.matches("\\d{4}")){
			System.out.println("\n");
			System.out.println("Error, only numbers");
			System.out.println("Enter choice :");
			z = kbReader.next();
	}//end while
	return Integer.parseInt(z);
  }//end validate


    ////////////////validate balance////////////////
  public static int validate(String x){
	while(!x.matches("\\d+")){
			System.out.println("\n");
			System.out.println("Error, only numbers");
			System.out.println("Please enter amount to lodge :");
			x = kbReader.next();
	}//end while
	return Integer.parseInt(x);
  }//end validate

  //////////////////choice 1 lodge/////////////////////
  public static int lodge(int x){
	//System.out.println(balance[position] = balance[position] + x);//enter any number then add up from balance
	return balance[position] + x;

  }//end lodge

  ///////////////validate withdraw////////////////
  public static int validates(String y){
	while(!y.matches("\\d+")){
			System.out.println("\n");
			System.out.println("Error, only numbers");
			System.out.println("Please enter amount :");
			y = kbReader.next();
	}//end while
	return Integer.parseInt(y);
  }

  //////////////////////choice 2 withdraw/////////////
  public static int withdraw(int y){
 	System.out.println("\n");
 	//System.out.println(balance[position] = balance[position] - mamount);
	return balance[position] - y;

 }//end withdraw

 ///////////////////validate pincheck/////////////////
 public static int pincheck(String m){
	while(!m.matches("\\d+")){
		System.out.println("Error, only numbers");
		System.out.println("Please enter pin :");
		m = kbReader.next();
	}//end while
	return Integer.parseInt(m);
 }//end pincheck

 ////////////////////choice 3 changepin/////////////////////
  public static int changepin(int m){
	for(int i =0; i<pin.length; i++){
			if(m == pin[i]){
				flag = false;
				break;
			}//end if
		}//end for

		if(flag == true){
			System.out.println("\n------------Pin in use--------------");//already have pin
		}
		else{
			System.out.println("\n------------Pin changed---------------");//new pin

		}

	System.out.println("\n");
	return pin[position];
  }//end changepin

  ////////////////choice 4 exit finish//////////////
  public static void exit(){
	login();// go back to login method call want do again login or quit

  }//end exit

}//end class