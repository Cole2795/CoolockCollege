/**
 * @(#)employee.java
 *Write a class employee with attributes name, id and address. The attributes should be set in a
 *setDetails method and not in the constructor. Also have set and get methods and a toString method.
 *
 * @author
 * @version 1.00 2016/3/10
 */


public class employee {
	private String name, address;
	private int id;

    public employee(Strin) {
    }


}