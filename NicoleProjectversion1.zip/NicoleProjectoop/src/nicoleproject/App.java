 /*Nicole Campbell Project
App class
*/

package nicoleproject;

import java.io.*;
import java.util.*;
import java.util.Date;
public class App {
    
    public static void main (String args[]){
        Scanner kbReader = new Scanner(System.in);
        
        //create object Item and Order
        System.out.println("WELCOME TO BOOK STORE");
    	Item i1 = new Item("Harry Potter", 4, 5, 56);
        Item i12 = new Item("Peter Pan", 8, 2, 8);
        Item i13 = new Item("BFG", 4, 9, 20);
        Item i14 = new Item("The Maze Runner", 32, 5, 22);
        Item i15 = new Item("Me before you", 11, 9, 25);
        System.out.println("");
        Order or1 = new Order(1, 7, i1, 23);
        Order or2 = new Order(2,10, i12, 10);
        Order or3 = new Order(3,18, i13, 15);
        Order or4 = new Order(4,15, i14, 30);
        Order or5 = new Order(5,19, i15, 40);
        
        //array item and order should be stored in arrays
        Item pack [] = {i1, i12, i13, i14, i15};
        Order packs [] = {or1, or2, or3, or4, or5};
        //print out details items in the array
        System.out.println("\nShowing all item in the array\n");
        for(int i = 0; i< 5; i++){
            //print out item details
            System.out.println("\n" + pack[i].toString() + "\n\n");
        }//end for loop
        //print out details orders in the array
        System.out.println("Showing all Order in the array\n");
        for(int i = 0; i< 5; i++){
            //print out order details
            System.out.println("\n" + packs[i].toString() + "\n");
        }//end for loop
        
                
        //update quantity of an item in stock when an order is accepted
        System.out.println("update item");
        for(int i =0; i<pack.length; i++){
            System.out.println(i1.decreaseQuantity(4));
            System.out.println(i13.increaseQuantity(2));
        }//end for loop
        
        //add quantity/stock when shipment is received
        System.out.println("");
        System.out.println("add stock");
        for(int i = 0; i<pack.length; i++){
            System.out.println(i1.addQuanity(i));
            System.out.println(i14.addQuanity(i));
            
        }//end loop
        
        System.out.println("");
        //display details of all items
        System.out.println("id of the item is : " + i1.getItem_ID());
        System.out.println("The name of the item is: " + i1.getName());
        System.out.println("Quantity of the item is: " + i1.getItem_Quanity());
        System.out.println("Unit Price of the item is: " + i1.getUnit_Price());
        
        //display details of all order
        System.out.println("");
        System.out.println("display details of all order");
        System.out.println("order id is: " + or1.getOrder_Id());
        System.out.println("order quantity is: " + or1.getOrder_quanity());
        
        
        //display order given id
        System.out.println("display order given id");
        Order id = new Order();
        id.getOrder_Id();
        
        for(int i = 0; i<pack.length; i++){
             if(id.getOrder_quanity() == 100){
                 System.out.println("newOrder[i]");
             }
             else{
                 System.out.println("not accept");
             }
        }//end loop
        
        System.out.println("");
        
}//main method
    
    //display static method array details
    public static void displayDetail(Item[] pack){
        for(int i = 0; i<pack.length; i++){
            System.out.println("2");
            System.out.println(pack[i]);
        }//end loop
    }//end displaydetail
    
    //display order
    public static void displayOrder(Order [] packs){
        for(int i = 0; i<packs.length; i++){
            System.out.println("5");
            System.out.println(packs[i].getOrder_Id());
        }
    }//end display order
    
    
        
        
    
     
    
}//end class
    

