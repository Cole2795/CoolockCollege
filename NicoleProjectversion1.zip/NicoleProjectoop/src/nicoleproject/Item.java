//Item class
package nicoleproject;

public class Item {
        //variable or fields
	private String name;
	private int item_id;
	private int item_quanity;
	private double unit_price;
        private static int  nextItemId = 99;   
    // first constructor    
    public Item(String n, int itemid, int itemqty, double up) {
    	this.name = n;
    	this.item_id = itemid;
    	this.item_quanity = itemqty;
    	this.unit_price = up;
        nextItemId++;
    }//end constructor
    //second constructor
    public Item(){
        this.item_id = nextItemId;
        this.name = "Unknown";
        this.item_quanity = 0;
        this.unit_price = 0;
        nextItemId++;
        
    }

    //set item name
    public void setName(String n){
    	this.name = n;
    }//end setName
    
    //get item name
    public String getName(){
    	return name;
    }//end getName
   
    //set id
    public void setItem_ID(int itemid){
    	this.item_id = itemid;
    }//end set item id
    //get id
    public int getItem_ID(){
    	return item_id;
    }//end get ItemID
    
    //set quantity
    /*public void setItem_Quanity(int itemqty){
    	this.item_quanity = itemqty;
    }//end Set item qty*/
    /**********************OR**********************************/
    public boolean setItem_Quanity(int quantity){
        if(quantity>0){
            this.item_quanity = quantity;
            return true;
        }
        else{
            return false;
        }
    }
    //get quantity
    public int getItem_Quanity(){
    	return item_quanity;
    }//end get item Quanity
    
    //set price
    public void setUnit_Price(double up){
    	this.unit_price = up;
    }
    /*public boolean setUnit_Price(double up){
           if(up>0){
                this.unitprice = up;
                return true;
            }
    else{
            return false;
    */
    //get price
    public double getUnit_Price(){
    	return unit_price;
    }//end getunit_price
    
    //stock
    public boolean inStock(int st){
      if(item_quanity > st){
          return true;
      }
      else{
          return false;
      }
   }//inStock
    
    //add stock 
    public boolean addQuanity(int stock){
        if(stock >0){
            item_quanity += stock;
            return true;
        }
        else{
            return false;
        }
      
   }//addtoStock
    public void addQ_uanity(int stok){
        item_quanity = item_quanity + stok;
   }//addtoStock
    
  
   
   //need Increase Quantity
    public boolean increaseQuantity(int increase){
        //boolean success = false;
         if(increase > 0){
             //item_quanity += increase;
            this.item_quanity += increase;
            return true;
             
         }
         return false;
    }
    //decrease quantity
    public boolean decreaseQuantity(int decrease){
       // boolean success = false;
         if(this.item_quanity > decrease){
             this.item_quanity -= decrease;
             return true;
             
         }
         return false;
    }
    
    
    //toString print out details in app class or use to display information
    public String toString(){
    	return "Detail of all items\nName: " + name + " \nItem ID: "+ item_id + " \nItem Quanity : " + item_quanity + " \nUnit Price : " + unit_price;
    }//end toString


}//end class
