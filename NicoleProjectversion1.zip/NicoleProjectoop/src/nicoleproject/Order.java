//Order class 
package nicoleproject;

/**
 *
 * @author D00187051
 */
public class Order {
        //variable or fields
	private int order_id;
	private int order_quanity;
        private Item i1;
        private double cost;
       private static int count = 99; 
    //first constructor
    public Order(int orid, int orqty, Item i1, double cost) {
    	this.order_id = count;
    	this.order_quanity = orqty;
    	this.i1 = i1;
        this.cost = cost;
        count++;

    }//end constructor
    //second constructor
    public Order(){
        this.order_id = count;
        this.order_quanity = 34;
        this.i1 = null;
        this.cost = 9;
        count++;
        
    }

   
        
    // set order Id
    public void setOrder_Id(int orid){
    	this.order_id = orid;
    }//set
    // get order id
    public int getOrder_Id(){
    	return order_quanity;
    }//get
    
     //set order quantity
    /*public void setOrder_quanity(int orqty){
    	this.order_quanity = orqty;
    }//end set*/
    public boolean setOrder_quanity(int orqty){
        if(orqty>0){
            order_quanity = orqty;
            return true;
        }
        return false;
    }
    //get order quantity
   public int getOrder_quanity(){
    	return order_quanity;
    }//get
   
   //item getItem
   public Item getItem(){
       return i1;
   }
   //set cost
   public boolean setCost(double ct){
       if(ct>0){
        this.cost = ct;
        return true;
       }
       return false;
   }
   //get cost
   public double getCost(){
       return cost;
   }
   
   //add stock 
    public void addQuanity(int stock){
        order_quanity = order_quanity + stock;
   }//addtoStock
    
    
    
    /*public boolean removeFromStock(int order_quantity){
        boolean success = false;
        
        if (this.order_quanity >= order_quanity){
            this.order_quanity = this.order_quanity - order_quanity;
            success = true;
        }
        return success;
    }*/
    //CalCost
    public double calCost(){
        cost = i1.getUnit_Price() * order_quanity;
        double discount;
        if(cost > 5000){
            discount = cost *.04;
            cost -= discount;
        }
        else if(cost  <= 5000 && cost >= 1000){
            discount = cost * .03;
            cost -=discount;
        }
        else {
            discount = 0;
            cost -= discount;
        }
        return cost;
    }//Calcost cost
    
    //toSTring print out details in app class or display information
    public String toString(){
    	return "Details of all Order\nOrder ID: " + order_id + "\nOrder Quanity : " + order_quanity + "\nCost : " + cost + "\n" +  i1.toString();
    }//end toString


}//end class
