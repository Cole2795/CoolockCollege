package ncversion4;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Objects;
  import java.io.FileInputStream;
  import java.io.FileOutputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Stock {
    
    private ArrayList<Item> itemstock;
    
    public Stock(){
        itemstock = new ArrayList<Item>();
    }
    
    public boolean addstock(Item i){
        if(!itemstock.contains(i)){
            itemstock.add(i);
            return true;
        }else{
            return false;
        }
    }
    
    public int numberofStock(){
        return itemstock.size();
    }
    
    public void listnostock(){
        System.out.println("Number of Stock");
        for(int i = 0; i<itemstock.size(); i++){
            System.out.println("list of Books " + (i+1) + ": " + itemstock.get(i));
        }
    }
    
    public void showallStock(){
        System.out.println(itemstock);
    }
    
//    public boolean removeStock( String name){
//        for(int i =0; i<name.size(); i++){
//            Item i = name.get(i);
//            if(i.getName().equals(name)){
//                name.remove(i);
//                return true;
//            }
//        }
//        return false;
//    }
    public void removestock(Item it){
        System.out.println("remove stock");
        itemstock.remove(it);
    }
    
    public int allStockleft(Item i){
       return i.getItem_Quanity();
    }
    
    public String displayItem(Item i){
        return i.toString();
    }
    
    public int validQuantity(Item i, int item_Quanity){
        if(item_Quanity < 0){
            System.out.println("out of stock");
        }
        else if(item_Quanity > 1){
            System.out.println("We have Stock");
            
        }
        return i.getItem_Quanity();
        
    }
//    public int getItemPos(Item item){
//        
//    }
    
    
    public Item findName(String name){
        for(int i =0; i<itemstock.size(); i++){
            String x = itemstock.get(i).getName();
            if(x.equals(name)){
                return itemstock.get(i);
            }
        }
       return null;
    }//end orderfind
    
    public int updateOrder(int item_quanity, Item i){
        Scanner kbReader = new Scanner(System.in);
        System.out.println("Please enter order");
        item_quanity = kbReader.nextInt();
         return i.getItem_Quanity() + item_quanity;
        
        
    }

//    @Override
//    public int hashCode() {
//        int hash = 7;
//        return hash;
//    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Stock other = (Stock) obj;
        if (!Objects.equals(this.itemstock, other.itemstock)) {
            return false;
        }
        return true;
    }
    
    public ArrayList<Item> getList(){
        return itemstock;
    }
        
     public void ReadFile() throws IOException {
    try {
        ObjectInputStream ois = new ObjectInputStream(new FileInputStream("products.bin"));
        itemstock = (ArrayList<Item>) ois.readObject();
        
    
    }   catch (ClassNotFoundException ex) {
            System.out.println("problem");
        }
     catch (IOException ex) {
               System.out.println(ex.toString());
        }

      
    
    
    

     }   
    
    
    
    
}
