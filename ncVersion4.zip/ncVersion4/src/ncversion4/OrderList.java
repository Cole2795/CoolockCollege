/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ncversion4;

/**
 *
 * @author Nicole
 */
import java.util.Scanner;
import java.util.ArrayList;
public class OrderList {
    
    
    private ArrayList<Order> orderlist;
    
    public OrderList(){
        orderlist = new ArrayList<>();
    }
    
    public void addBook(Order o){
        orderlist.add(o);
    }
    
    public int numberBook(){
        return orderlist.size();
    }
    
    public void listnoBook(){
        System.out.println("Number of Books");
        for(int i = 0; i<orderlist.size(); i++){
            System.out.println("list of Books " + (i+1) + ": " + orderlist.get(i));
        }
    }
    
    public void showallBook(){
        System.out.println(orderlist);
    }
    
    /*public boolean removeBook(String name){
        for(int i =0; i<orderbooks.size(); i++){
            Order or = orderbooks.get(i);
            if(or.getItem().equals(name)){
                orderbooks.remove(i);
                return true;
            }
        }
        return false;
    }*/
    public void removeOrder(Order or){
        System.out.println("remove Order");
        orderlist.remove(or);
        
    }
    
    public Item showItem(){
        for(int i =0; i<orderlist.size(); i++){
            String x = orderlist.get(i).toString();
            if(x.equals(x)){
                return orderlist.get(i).getItem();
            }
            
        }
        return null;
    }
    
    //update order
    public int updateOrder(int orderQuantity2, Order o){
        Scanner kbReader = new Scanner(System.in);
        System.out.println("Please enter order");
        orderQuantity2 = kbReader.nextInt();
         return o.getOrderQuantity() + orderQuantity2;
        
        
    }
    
    public double updateCal(Order ri){
        return ri.getCost();
    }

    //update balance
    public double updateBalance(int bal, BusinessCustomer b){
             Scanner kbReader = new Scanner(System.in);
            System.out.println("please enter balance");
            bal = kbReader.nextInt();
            return b.getBalance() + bal;
    }
    
    //update loyalpoints
    public double updateLoyalPoints(int point, PrivateCustomer p){
        Scanner kbReader = new Scanner(System.in);
        System.out.println("please enter loyal");
        point = kbReader.nextInt();
        return p.getPoints() + point;
    }
    
    
//    public Order find(String name){
//        for(int i =0; i<orderlist.size(); i++){
//            String x = orderlist.get(i).getOrderId();
//            if(x.equals(name)){
//                return orderlist.get(i);
//            }
//        }
//        return null;
//    }//end findStaff
    
    //Display details of all orders
    public String DisplaydetailOrder(Order o){
        return o.toString();
    }
    
    //Display all order for specified item
    public String DisplayOrderItem(Order o, Item i){
        return o.toString() + " " + i.toString();
    }
    
    public String DisplayCustomer(Order o, Customer c){
        return orderlist.add(o) + c.toString();
    }
    
    public int UpdateStock(Item i){
        return i.getItem_Quanity();
    }
    
}//end class
