/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ncversion4;

/**
 *
 * @author Nicole
 */
public class BusinessCustomer extends Customer {
    
    private double balance =0;
    private double credit;
    

  
    
    /*public balance(){
        balance = 34.3;
        credit = 7;
    }*/
    
    public BusinessCustomer(String name, String address, String email, String type, int id, double balance, double credit){
        super(name, address, email, type, id);
        this.balance = balance;
        this.credit = credit;
        
    }
    
    public void setBalance(double balance){
          
           this.balance = balance;
    }
    
    public double getBalance(){
        return this.balance;
    }
    
    public void setCredit(double credit){
        this.credit = credit;
    }
    
    public double getCredit(){
        return credit;
    }
    
    public int increaseQuantity(int increase){
        //boolean success = false;
        // if(increase > 0){
             //item_quanity += increase;
            this.balance += increase;
           // return true;
             
         //}
          return increase;
    }
    //decrease quantity
    public int decreaseQuantity(int decrease){
       // boolean success = false;
        // if(item_quanity >  0){
             this.balance -= decrease;
             //return true;
             
        //// }
        // else if (item_quanity < 0){
          //   System.out.println("Not Available");
         //}
         //return balance;
         return decrease;
    }
    
   
      
    
    public String toString(){
        return super.toString() + "\nBalance : " + balance + "\nCredit : " + credit;
    }
    
}
