/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ncversion4;

/**
 *
 * @author Nicole
 */
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.Objects;
import java.util.Collections;
import java.util.logging.Level;
import java.util.logging.Logger;
public class CustomerData {
 
    private ArrayList<Customer>custData;
    
    public CustomerData(){
        custData = new ArrayList<>();
    }
    public void addCustomer(Customer c){
         if(!custData.contains(c)){
            custData.add(c);
        }
    }
    
    
    
   

//    @Override
//    public int hashCode() {
//        int hash = 7;
//        return hash;
//    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final CustomerData other = (CustomerData) obj;
        if (!Objects.equals(this.custData, other.custData)) {
            return false;
        }
        return true;
    }
    
    public int numberCustomer(){
        return custData.size();
    }
    
    public void listnoCustomer(){
        System.out.println("Number of Books");
        for(int i = 0; i<custData.size(); i++){
            System.out.println("list of Books " + (i+1) + ": " + custData.get(i));
        }
    }
    
    public void showallcustomer(){
        System.out.println(custData);
    }
    
    public double totalBalance(BusinessCustomer b){
       return b.getBalance();
    }
    
    public String displayCustomer(Customer c){
        return c.toString();
    }
    
    
    
    public Customer findName(String name){
        for(int i =0; i<custData.size(); i++){
            String c = custData.get(i).getName();
            if(c.equals(name)){
              return custData.get(i);
              
            }
        }
        return null;
    }
    public void removeCustomer(Customer cu){
        System.out.println("remove customer");
        custData.remove(cu);
    }
    
//    public void removeDuplicates(){
//	int total = numberCustomer;
//	Collections.sort(custData);
//	for(int i = total-1;i >0;i--){
//		if (custData.get(i).equals(custData.get(i-1))) {
//                	custData.remove(i);
//			numberCustomer--;
//				}
//        	}
//    }
     

    
    
    
    /*
    public Order find(String name){
        for(int i =0; i<orderbooks.size(); i++){
            String x = orderbooks.get(i).getItem();
            if(x.equals(name)){
                return orderbooks.get(i);
            }
        }
        return null;
    }//end findStaff*/

   
}
