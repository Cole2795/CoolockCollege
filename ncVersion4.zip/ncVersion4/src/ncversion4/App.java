
package ncversion4;

/* @author Nicole */
import java.util.*;
import java.util.ArrayList;
import java.io.*;
import java.util.Date;
public class App {

    
    public static void main(String[] args) {
        Scanner kbReader = new Scanner(System.in);
        
        Date d = new Date();
        System.out.println(d);
        
         //customer object
        Customer c1 = new Customer("nicole", "Balbriggan", "nicole@gmail.com", "anything", 56);
        Customer c2 = new Customer("Ashley", "Drogheda", "Ashley@gmail.com", "bookd", 82);
        Customer c3 = new Customer("Keith", "Louth", "Keith@hotmail.com", "DVD", 56);
        Customer c4 = new Customer("Sarah", "Cork", "Sarah@hotmail.com", "Card", 46);
        Customer c5 = new Customer("Ailson", "Slgo", "Ailson@hotmail.com", "clothes", 26);
       
        CustomerData cd = new CustomerData();
       
        Customer cust [] = {c1, c2, c3}; //dont need array
        
        System.out.println("");
        //balance object
        BusinessCustomer b1 = new BusinessCustomer("nicole", "Balbriggan", "nicole@gmail.com", "anything", 56, 87, 9);
        BusinessCustomer b2 = new BusinessCustomer("Sarah", "Dublin", "Sarah@gmail.com", "books", 53, 9, 99);
        BusinessCustomer b3 = new BusinessCustomer("Kieran", "Ashtown", "Keiran@gmail.com", "dvd", 6, 17, 20);
        //balance bal [] = {b1,b2,b3}; //don't need array
       
        
        System.out.println("");
       //private object
        PrivateCustomer p1 = new PrivateCustomer("nicole", "Balbriggan", "nicole@gmail.com", "anything", 56, 30);
        PrivateCustomer p2 = new PrivateCustomer("SJ", "Kerry", "SJ@gmail.com", "mag", 6, 30);
        PrivateCustomer p3 = new PrivateCustomer("Scott", "Cork", "Scott@gmail.com", "books", 4, 50);
        //Private pr [] = {p1, p2, p3};
        //display all customer detail from ArrayList CustomerData
 //////////////////////////////////////////////////////////////////////////////////version 1 but dont need array just Change it//////////////////////////////////////
               
        //create object Item and Order
        System.out.println("");
       
        
    	Item i1 = new Item("Harry Potter", 4, 5, 56);
        Item i12 = new Item("Peter Pan", 8, 2, 8);
        Item i13 = new Item("BFG", 4, 9, 20);
        Item i14 = new Item("The Maze Runner", 32, 5, 22);
        Item i15 = new Item("Me before you", 11, 9, 25);
        Stock st  = new Stock(); //arraylist
        Item pack [] = {i1, i12, i13, i14, i15};
        AllStock(pack);
        
        
        // order items
        Order or1 = new Order(1, i1 , c1);
        Order or2 = new Order(2, i12, c2);
        Order or3 = new Order(3, i13, c3);
        Order or4 = new Order(4, i14, c4);
        Order or5 = new Order(5, i15, c5);
        OrderList or = new OrderList(); //arryList
        
        System.out.println("");
        
        
        
       
           
 
////////////////////////////////////////////////////////////////////////////////////////////Version 2////////////////////////////////////////////////////////////////////////////////////
        
       //3)display customer details from ArrayList
        //cd.addCustomer(c1);
        cd.addCustomer(b1);
        cd.addCustomer(b2);
        cd.addCustomer(b3);
        System.out.println(cd.numberCustomer());
        cd.showallcustomer();
        System.out.println("");
        //5)display order details from ArrayList OrderBook
        or.addBook(or1);
        or.addBook(or2);
        or.addBook(or3);
        System.out.println(or.numberBook());
        or.showallBook();
         System.out.println("");
         //5)display item details from ArrayList Stock
         st.addstock(i1);
         st.addstock(i12);
         st.addstock(i13);
         System.out.println(st.numberofStock());
         st.showallStock();
        
        //4)delete a specified customer, order or item object
        System.out.println("\nDelete customer or order or item");
        cd.removeCustomer(c3);
        or.removeOrder(or2);
        st.removestock(i12);
        //System.out.println("Customer have " + cd.numberCustomer() + "\nOrder have " + or.numberBook() + "\nItem have" + st.numberofStock());
        //display the details of any cutsomer, order or item after you delete details any customer, order or item
        //5)
        cd.showallcustomer();
        or.showallBook();
        st.showallStock();
        //display all order for particular item
        System.out.println(or.showItem());
        System.out.println(or.showItem());
        
              
        // 8) Return all items where the quantity in stock is less than a particular value.
        for(int i =0; i<pack.length; i++){
           System.out.println("Quantity " + pack[i].getItem_Quanity());
           
        }//end for loop
        
        //find Item
        System.out.println("Find Item " + st.findName("Harry Potter"));
        //find Customer
        System.out.println("Find Customer " + cd.findName("nicole"));
        
        //Update Stock
        System.out.println(or.UpdateStock(i1));
        
        
        
        //calculate cost
        System.out.println(or.updateCal(or5));
        
        //update Balance
        System.out.println(or.updateBalance(3, b3));
        
        //cal and update logalpoint
        System.out.println(or.updateCal(or5) + or.updateLoyalPoints(3, p3));
        
        //update quanity stock
        st.updateOrder(4, i1);
        
        //9) return a summary of a particular  customer orders
        
         System.out.println("What your name? :");
        String name = kbReader.nextLine();
        int found = 0;
        for(int i =0; i<cust.length; i++){
            if(cust[i].getName().equals(name)){
                if(found == 0){
                    found = 0;
                    //System.out.println("\nName : " + cust[i].getName() + "\nAddress : " + cust[i].getId() + "\nemail : " + cust[i].getEmail());
                    System.out.println("what you would like to order?");
                    String order = kbReader.nextLine();
                    for(int j = 0; j<pack.length; j++){
                        if(pack[j].getName().equals(order)){
                            System.out.println("\nName : " + pack[j].getName() + "\nItem Quanity : " + pack[j].getItem_Quanity() + "\nPrice : " + pack[j].getUnit_Price());
                            System.out.println("How many would you like?");
                            int number = kbReader.nextInt();
                            System.out.println("You order Details\nName : " + cust[i].getName() + "\nAddress : " + cust[i].getId() + "\nEmail : " + cust[i].getEmail() + "\n" + pack[j].getName() +  "\nTotal : " + pack[j].getUnit_Price() * number);
                            
                                
                   
                        }//end if
                    }//end for
                   
                }//end if
            }//end if
        }//end for
        
        
        
        //2)1 loyalty point is assigned for every €100 spent.
        System.out.println("");
        System.out.println("Loyal Point");
        System.out.println(p1.CalculateLoyaltyPoint(4) +  " points");
       
        
        
        
        
        
        
        
    }//end main
    
    ///From version 1
     // Displaying stock array
    public static void AllStock(Item[] pack) {
        for (int i = 0; i < pack.length; i++) {
            System.out.println(pack[i]);
        }
        System.out.println("\n");
    }

// Displaying order array      
    public static void NewOrder(Order[] newOrder) {
        for (int i = 0; i < newOrder.length; i++) {
            System.out.println(newOrder[i]);
        }
        System.out.println("\n");
    }
    
//    //version 2
//    public static void cust(customer cd){
//        for (int i = 0; i < cd.length; i++) {
//            System.out.println(cd[i]);
//        }
//        System.out.println("\n");
//    }
    
    
      
    
}//end classs
